//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package android;

public final class R {
    public R() {
        throw new RuntimeException("Stub!");
    }

    public static final class xml {
        public xml() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class transition {
        public static final int explode = 17760259;
        public static final int fade = 17760258;
        public static final int move = 17760257;
        public static final int no_transition = 17760256;
        public static final int slide_bottom = 17760260;
        public static final int slide_left = 17760263;
        public static final int slide_right = 17760262;
        public static final int slide_top = 17760261;

        public transition() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class style {
        public static final int Animation = 16973824;
        public static final int Animation_Activity = 16973825;
        public static final int Animation_Dialog = 16973826;
        public static final int Animation_InputMethod = 16973910;
        public static final int Animation_Toast = 16973828;
        public static final int Animation_Translucent = 16973827;
        public static final int DeviceDefault_ButtonBar = 16974287;
        public static final int DeviceDefault_ButtonBar_AlertDialog = 16974288;
        public static final int DeviceDefault_Light_ButtonBar = 16974290;
        public static final int DeviceDefault_Light_ButtonBar_AlertDialog = 16974291;
        public static final int DeviceDefault_Light_SegmentedButton = 16974292;
        public static final int DeviceDefault_SegmentedButton = 16974289;
        public static final int Holo_ButtonBar = 16974053;
        public static final int Holo_ButtonBar_AlertDialog = 16974055;
        public static final int Holo_Light_ButtonBar = 16974054;
        public static final int Holo_Light_ButtonBar_AlertDialog = 16974056;
        public static final int Holo_Light_SegmentedButton = 16974058;
        public static final int Holo_SegmentedButton = 16974057;
        public static final int MediaButton = 16973879;
        public static final int MediaButton_Ffwd = 16973883;
        public static final int MediaButton_Next = 16973881;
        public static final int MediaButton_Pause = 16973885;
        public static final int MediaButton_Play = 16973882;
        public static final int MediaButton_Previous = 16973880;
        public static final int MediaButton_Rew = 16973884;
        public static final int TextAppearance = 16973886;
        public static final int TextAppearance_DeviceDefault = 16974253;
        public static final int TextAppearance_DeviceDefault_DialogWindowTitle = 16974264;
        public static final int TextAppearance_DeviceDefault_Inverse = 16974254;
        public static final int TextAppearance_DeviceDefault_Large = 16974255;
        public static final int TextAppearance_DeviceDefault_Large_Inverse = 16974256;
        public static final int TextAppearance_DeviceDefault_Medium = 16974257;
        public static final int TextAppearance_DeviceDefault_Medium_Inverse = 16974258;
        public static final int TextAppearance_DeviceDefault_SearchResult_Subtitle = 16974262;
        public static final int TextAppearance_DeviceDefault_SearchResult_Title = 16974261;
        public static final int TextAppearance_DeviceDefault_Small = 16974259;
        public static final int TextAppearance_DeviceDefault_Small_Inverse = 16974260;
        public static final int TextAppearance_DeviceDefault_Widget = 16974265;
        public static final int TextAppearance_DeviceDefault_Widget_ActionBar_Menu = 16974286;
        public static final int TextAppearance_DeviceDefault_Widget_ActionBar_Subtitle = 16974279;
        /** @deprecated */
        @Deprecated
        public static final int TextAppearance_DeviceDefault_Widget_ActionBar_Subtitle_Inverse = 16974283;
        public static final int TextAppearance_DeviceDefault_Widget_ActionBar_Title = 16974278;
        /** @deprecated */
        @Deprecated
        public static final int TextAppearance_DeviceDefault_Widget_ActionBar_Title_Inverse = 16974282;
        public static final int TextAppearance_DeviceDefault_Widget_ActionMode_Subtitle = 16974281;
        /** @deprecated */
        @Deprecated
        public static final int TextAppearance_DeviceDefault_Widget_ActionMode_Subtitle_Inverse = 16974285;
        public static final int TextAppearance_DeviceDefault_Widget_ActionMode_Title = 16974280;
        /** @deprecated */
        @Deprecated
        public static final int TextAppearance_DeviceDefault_Widget_ActionMode_Title_Inverse = 16974284;
        public static final int TextAppearance_DeviceDefault_Widget_Button = 16974266;
        public static final int TextAppearance_DeviceDefault_Widget_DropDownHint = 16974271;
        public static final int TextAppearance_DeviceDefault_Widget_DropDownItem = 16974272;
        public static final int TextAppearance_DeviceDefault_Widget_EditText = 16974274;
        public static final int TextAppearance_DeviceDefault_Widget_IconMenu_Item = 16974267;
        public static final int TextAppearance_DeviceDefault_Widget_PopupMenu = 16974275;
        public static final int TextAppearance_DeviceDefault_Widget_PopupMenu_Large = 16974276;
        public static final int TextAppearance_DeviceDefault_Widget_PopupMenu_Small = 16974277;
        public static final int TextAppearance_DeviceDefault_Widget_TabWidget = 16974268;
        public static final int TextAppearance_DeviceDefault_Widget_TextView = 16974269;
        public static final int TextAppearance_DeviceDefault_Widget_TextView_PopupMenu = 16974270;
        public static final int TextAppearance_DeviceDefault_Widget_TextView_SpinnerItem = 16974273;
        public static final int TextAppearance_DeviceDefault_WindowTitle = 16974263;
        public static final int TextAppearance_DialogWindowTitle = 16973889;
        public static final int TextAppearance_Holo = 16974075;
        public static final int TextAppearance_Holo_DialogWindowTitle = 16974103;
        public static final int TextAppearance_Holo_Inverse = 16974076;
        public static final int TextAppearance_Holo_Large = 16974077;
        public static final int TextAppearance_Holo_Large_Inverse = 16974078;
        public static final int TextAppearance_Holo_Medium = 16974079;
        public static final int TextAppearance_Holo_Medium_Inverse = 16974080;
        public static final int TextAppearance_Holo_SearchResult_Subtitle = 16974084;
        public static final int TextAppearance_Holo_SearchResult_Title = 16974083;
        public static final int TextAppearance_Holo_Small = 16974081;
        public static final int TextAppearance_Holo_Small_Inverse = 16974082;
        public static final int TextAppearance_Holo_Widget = 16974085;
        public static final int TextAppearance_Holo_Widget_ActionBar_Menu = 16974112;
        public static final int TextAppearance_Holo_Widget_ActionBar_Subtitle = 16974099;
        public static final int TextAppearance_Holo_Widget_ActionBar_Subtitle_Inverse = 16974109;
        public static final int TextAppearance_Holo_Widget_ActionBar_Title = 16974098;
        public static final int TextAppearance_Holo_Widget_ActionBar_Title_Inverse = 16974108;
        public static final int TextAppearance_Holo_Widget_ActionMode_Subtitle = 16974101;
        public static final int TextAppearance_Holo_Widget_ActionMode_Subtitle_Inverse = 16974111;
        public static final int TextAppearance_Holo_Widget_ActionMode_Title = 16974100;
        public static final int TextAppearance_Holo_Widget_ActionMode_Title_Inverse = 16974110;
        public static final int TextAppearance_Holo_Widget_Button = 16974086;
        public static final int TextAppearance_Holo_Widget_DropDownHint = 16974091;
        public static final int TextAppearance_Holo_Widget_DropDownItem = 16974092;
        public static final int TextAppearance_Holo_Widget_EditText = 16974094;
        public static final int TextAppearance_Holo_Widget_IconMenu_Item = 16974087;
        public static final int TextAppearance_Holo_Widget_PopupMenu = 16974095;
        public static final int TextAppearance_Holo_Widget_PopupMenu_Large = 16974096;
        public static final int TextAppearance_Holo_Widget_PopupMenu_Small = 16974097;
        public static final int TextAppearance_Holo_Widget_TabWidget = 16974088;
        public static final int TextAppearance_Holo_Widget_TextView = 16974089;
        public static final int TextAppearance_Holo_Widget_TextView_PopupMenu = 16974090;
        public static final int TextAppearance_Holo_Widget_TextView_SpinnerItem = 16974093;
        public static final int TextAppearance_Holo_WindowTitle = 16974102;
        public static final int TextAppearance_Inverse = 16973887;
        public static final int TextAppearance_Large = 16973890;
        public static final int TextAppearance_Large_Inverse = 16973891;
        public static final int TextAppearance_Material = 16974317;
        public static final int TextAppearance_Material_Body1 = 16974320;
        public static final int TextAppearance_Material_Body2 = 16974319;
        public static final int TextAppearance_Material_Button = 16974318;
        public static final int TextAppearance_Material_Caption = 16974321;
        public static final int TextAppearance_Material_DialogWindowTitle = 16974322;
        public static final int TextAppearance_Material_Display1 = 16974326;
        public static final int TextAppearance_Material_Display2 = 16974325;
        public static final int TextAppearance_Material_Display3 = 16974324;
        public static final int TextAppearance_Material_Display4 = 16974323;
        public static final int TextAppearance_Material_Headline = 16974327;
        public static final int TextAppearance_Material_Inverse = 16974328;
        public static final int TextAppearance_Material_Large = 16974329;
        public static final int TextAppearance_Material_Large_Inverse = 16974330;
        public static final int TextAppearance_Material_Medium = 16974331;
        public static final int TextAppearance_Material_Medium_Inverse = 16974332;
        public static final int TextAppearance_Material_Menu = 16974333;
        public static final int TextAppearance_Material_Notification = 16974334;
        public static final int TextAppearance_Material_Notification_Emphasis = 16974335;
        public static final int TextAppearance_Material_Notification_Info = 16974336;
        public static final int TextAppearance_Material_Notification_Line2 = 16974337;
        public static final int TextAppearance_Material_Notification_Time = 16974338;
        public static final int TextAppearance_Material_Notification_Title = 16974339;
        public static final int TextAppearance_Material_SearchResult_Subtitle = 16974340;
        public static final int TextAppearance_Material_SearchResult_Title = 16974341;
        public static final int TextAppearance_Material_Small = 16974342;
        public static final int TextAppearance_Material_Small_Inverse = 16974343;
        public static final int TextAppearance_Material_Subhead = 16974344;
        public static final int TextAppearance_Material_Title = 16974345;
        public static final int TextAppearance_Material_Widget = 16974347;
        public static final int TextAppearance_Material_Widget_ActionBar_Menu = 16974348;
        public static final int TextAppearance_Material_Widget_ActionBar_Subtitle = 16974349;
        public static final int TextAppearance_Material_Widget_ActionBar_Subtitle_Inverse = 16974350;
        public static final int TextAppearance_Material_Widget_ActionBar_Title = 16974351;
        public static final int TextAppearance_Material_Widget_ActionBar_Title_Inverse = 16974352;
        public static final int TextAppearance_Material_Widget_ActionMode_Subtitle = 16974353;
        public static final int TextAppearance_Material_Widget_ActionMode_Subtitle_Inverse = 16974354;
        public static final int TextAppearance_Material_Widget_ActionMode_Title = 16974355;
        public static final int TextAppearance_Material_Widget_ActionMode_Title_Inverse = 16974356;
        public static final int TextAppearance_Material_Widget_Button = 16974357;
        public static final int TextAppearance_Material_Widget_Button_Borderless_Colored = 16974559;
        public static final int TextAppearance_Material_Widget_Button_Colored = 16974558;
        public static final int TextAppearance_Material_Widget_Button_Inverse = 16974548;
        public static final int TextAppearance_Material_Widget_DropDownHint = 16974358;
        public static final int TextAppearance_Material_Widget_DropDownItem = 16974359;
        public static final int TextAppearance_Material_Widget_EditText = 16974360;
        public static final int TextAppearance_Material_Widget_IconMenu_Item = 16974361;
        public static final int TextAppearance_Material_Widget_PopupMenu = 16974362;
        public static final int TextAppearance_Material_Widget_PopupMenu_Large = 16974363;
        public static final int TextAppearance_Material_Widget_PopupMenu_Small = 16974364;
        public static final int TextAppearance_Material_Widget_TabWidget = 16974365;
        public static final int TextAppearance_Material_Widget_TextView = 16974366;
        public static final int TextAppearance_Material_Widget_TextView_PopupMenu = 16974367;
        public static final int TextAppearance_Material_Widget_TextView_SpinnerItem = 16974368;
        public static final int TextAppearance_Material_Widget_Toolbar_Subtitle = 16974369;
        public static final int TextAppearance_Material_Widget_Toolbar_Title = 16974370;
        public static final int TextAppearance_Material_WindowTitle = 16974346;
        public static final int TextAppearance_Medium = 16973892;
        public static final int TextAppearance_Medium_Inverse = 16973893;
        public static final int TextAppearance_Small = 16973894;
        public static final int TextAppearance_Small_Inverse = 16973895;
        public static final int TextAppearance_StatusBar_EventContent = 16973927;
        public static final int TextAppearance_StatusBar_EventContent_Title = 16973928;
        public static final int TextAppearance_StatusBar_Icon = 16973926;
        public static final int TextAppearance_StatusBar_Title = 16973925;
        public static final int TextAppearance_SuggestionHighlight = 16974104;
        public static final int TextAppearance_Theme = 16973888;
        public static final int TextAppearance_Theme_Dialog = 16973896;
        public static final int TextAppearance_Widget = 16973897;
        public static final int TextAppearance_Widget_Button = 16973898;
        public static final int TextAppearance_Widget_DropDownHint = 16973904;
        public static final int TextAppearance_Widget_DropDownItem = 16973905;
        public static final int TextAppearance_Widget_EditText = 16973900;
        public static final int TextAppearance_Widget_IconMenu_Item = 16973899;
        public static final int TextAppearance_Widget_PopupMenu_Large = 16973952;
        public static final int TextAppearance_Widget_PopupMenu_Small = 16973953;
        public static final int TextAppearance_Widget_TabWidget = 16973901;
        public static final int TextAppearance_Widget_TextView = 16973902;
        public static final int TextAppearance_Widget_TextView_PopupMenu = 16973903;
        public static final int TextAppearance_Widget_TextView_SpinnerItem = 16973906;
        public static final int TextAppearance_WindowTitle = 16973907;
        public static final int Theme = 16973829;
        public static final int ThemeOverlay = 16974407;
        public static final int ThemeOverlay_DeviceDefault_Accent_DayNight = 16974564;
        public static final int ThemeOverlay_Material = 16974408;
        public static final int ThemeOverlay_Material_ActionBar = 16974409;
        public static final int ThemeOverlay_Material_Dark = 16974411;
        public static final int ThemeOverlay_Material_Dark_ActionBar = 16974412;
        public static final int ThemeOverlay_Material_Dialog = 16974550;
        public static final int ThemeOverlay_Material_Dialog_Alert = 16974551;
        public static final int ThemeOverlay_Material_Light = 16974410;
        public static final int Theme_Black = 16973832;
        public static final int Theme_Black_NoTitleBar = 16973833;
        public static final int Theme_Black_NoTitleBar_Fullscreen = 16973834;
        public static final int Theme_DeviceDefault = 16974120;
        public static final int Theme_DeviceDefault_DayNight = 16974563;
        public static final int Theme_DeviceDefault_Dialog = 16974126;
        public static final int Theme_DeviceDefault_DialogWhenLarge = 16974134;
        public static final int Theme_DeviceDefault_DialogWhenLarge_NoActionBar = 16974135;
        public static final int Theme_DeviceDefault_Dialog_Alert = 16974545;
        public static final int Theme_DeviceDefault_Dialog_MinWidth = 16974127;
        public static final int Theme_DeviceDefault_Dialog_NoActionBar = 16974128;
        public static final int Theme_DeviceDefault_Dialog_NoActionBar_MinWidth = 16974129;
        public static final int Theme_DeviceDefault_InputMethod = 16974142;
        public static final int Theme_DeviceDefault_Light = 16974123;
        public static final int Theme_DeviceDefault_Light_DarkActionBar = 16974143;
        public static final int Theme_DeviceDefault_Light_Dialog = 16974130;
        public static final int Theme_DeviceDefault_Light_DialogWhenLarge = 16974136;
        public static final int Theme_DeviceDefault_Light_DialogWhenLarge_NoActionBar = 16974137;
        public static final int Theme_DeviceDefault_Light_Dialog_Alert = 16974546;
        public static final int Theme_DeviceDefault_Light_Dialog_MinWidth = 16974131;
        public static final int Theme_DeviceDefault_Light_Dialog_NoActionBar = 16974132;
        public static final int Theme_DeviceDefault_Light_Dialog_NoActionBar_MinWidth = 16974133;
        public static final int Theme_DeviceDefault_Light_NoActionBar = 16974124;
        public static final int Theme_DeviceDefault_Light_NoActionBar_Fullscreen = 16974125;
        public static final int Theme_DeviceDefault_Light_NoActionBar_Overscan = 16974304;
        public static final int Theme_DeviceDefault_Light_NoActionBar_TranslucentDecor = 16974308;
        public static final int Theme_DeviceDefault_Light_Panel = 16974139;
        public static final int Theme_DeviceDefault_NoActionBar = 16974121;
        public static final int Theme_DeviceDefault_NoActionBar_Fullscreen = 16974122;
        public static final int Theme_DeviceDefault_NoActionBar_Overscan = 16974303;
        public static final int Theme_DeviceDefault_NoActionBar_TranslucentDecor = 16974307;
        public static final int Theme_DeviceDefault_Panel = 16974138;
        public static final int Theme_DeviceDefault_Settings = 16974371;
        public static final int Theme_DeviceDefault_Wallpaper = 16974140;
        public static final int Theme_DeviceDefault_Wallpaper_NoTitleBar = 16974141;
        public static final int Theme_Dialog = 16973835;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo = 16973931;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Dialog = 16973935;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_DialogWhenLarge = 16973943;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_DialogWhenLarge_NoActionBar = 16973944;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Dialog_MinWidth = 16973936;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Dialog_NoActionBar = 16973937;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Dialog_NoActionBar_MinWidth = 16973938;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_InputMethod = 16973951;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light = 16973934;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_DarkActionBar = 16974105;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_Dialog = 16973939;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_DialogWhenLarge = 16973945;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_DialogWhenLarge_NoActionBar = 16973946;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_Dialog_MinWidth = 16973940;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_Dialog_NoActionBar = 16973941;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_Dialog_NoActionBar_MinWidth = 16973942;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_NoActionBar = 16974064;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_NoActionBar_Fullscreen = 16974065;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_NoActionBar_Overscan = 16974302;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_NoActionBar_TranslucentDecor = 16974306;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Light_Panel = 16973948;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_NoActionBar = 16973932;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_NoActionBar_Fullscreen = 16973933;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_NoActionBar_Overscan = 16974301;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_NoActionBar_TranslucentDecor = 16974305;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Panel = 16973947;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Wallpaper = 16973949;
        /** @deprecated */
        @Deprecated
        public static final int Theme_Holo_Wallpaper_NoTitleBar = 16973950;
        public static final int Theme_InputMethod = 16973908;
        public static final int Theme_Light = 16973836;
        public static final int Theme_Light_NoTitleBar = 16973837;
        public static final int Theme_Light_NoTitleBar_Fullscreen = 16973838;
        public static final int Theme_Light_Panel = 16973914;
        public static final int Theme_Light_WallpaperSettings = 16973922;
        public static final int Theme_Material = 16974372;
        public static final int Theme_Material_Dialog = 16974373;
        public static final int Theme_Material_DialogWhenLarge = 16974379;
        public static final int Theme_Material_DialogWhenLarge_NoActionBar = 16974380;
        public static final int Theme_Material_Dialog_Alert = 16974374;
        public static final int Theme_Material_Dialog_MinWidth = 16974375;
        public static final int Theme_Material_Dialog_NoActionBar = 16974376;
        public static final int Theme_Material_Dialog_NoActionBar_MinWidth = 16974377;
        public static final int Theme_Material_Dialog_Presentation = 16974378;
        public static final int Theme_Material_InputMethod = 16974381;
        public static final int Theme_Material_Light = 16974391;
        public static final int Theme_Material_Light_DarkActionBar = 16974392;
        public static final int Theme_Material_Light_Dialog = 16974393;
        public static final int Theme_Material_Light_DialogWhenLarge = 16974399;
        public static final int Theme_Material_Light_DialogWhenLarge_DarkActionBar = 16974552;
        public static final int Theme_Material_Light_DialogWhenLarge_NoActionBar = 16974400;
        public static final int Theme_Material_Light_Dialog_Alert = 16974394;
        public static final int Theme_Material_Light_Dialog_MinWidth = 16974395;
        public static final int Theme_Material_Light_Dialog_NoActionBar = 16974396;
        public static final int Theme_Material_Light_Dialog_NoActionBar_MinWidth = 16974397;
        public static final int Theme_Material_Light_Dialog_Presentation = 16974398;
        public static final int Theme_Material_Light_LightStatusBar = 16974549;
        public static final int Theme_Material_Light_NoActionBar = 16974401;
        public static final int Theme_Material_Light_NoActionBar_Fullscreen = 16974402;
        public static final int Theme_Material_Light_NoActionBar_Overscan = 16974403;
        public static final int Theme_Material_Light_NoActionBar_TranslucentDecor = 16974404;
        public static final int Theme_Material_Light_Panel = 16974405;
        public static final int Theme_Material_Light_Voice = 16974406;
        public static final int Theme_Material_NoActionBar = 16974382;
        public static final int Theme_Material_NoActionBar_Fullscreen = 16974383;
        public static final int Theme_Material_NoActionBar_Overscan = 16974384;
        public static final int Theme_Material_NoActionBar_TranslucentDecor = 16974385;
        public static final int Theme_Material_Panel = 16974386;
        public static final int Theme_Material_Settings = 16974387;
        public static final int Theme_Material_Voice = 16974388;
        public static final int Theme_Material_Wallpaper = 16974389;
        public static final int Theme_Material_Wallpaper_NoTitleBar = 16974390;
        public static final int Theme_NoDisplay = 16973909;
        public static final int Theme_NoTitleBar = 16973830;
        public static final int Theme_NoTitleBar_Fullscreen = 16973831;
        public static final int Theme_NoTitleBar_OverlayActionModes = 16973930;
        public static final int Theme_Panel = 16973913;
        public static final int Theme_Translucent = 16973839;
        public static final int Theme_Translucent_NoTitleBar = 16973840;
        public static final int Theme_Translucent_NoTitleBar_Fullscreen = 16973841;
        public static final int Theme_Wallpaper = 16973918;
        public static final int Theme_WallpaperSettings = 16973921;
        public static final int Theme_Wallpaper_NoTitleBar = 16973919;
        public static final int Theme_Wallpaper_NoTitleBar_Fullscreen = 16973920;
        public static final int Theme_WithActionBar = 16973929;
        public static final int Widget = 16973842;
        public static final int Widget_AbsListView = 16973843;
        public static final int Widget_ActionBar = 16973954;
        public static final int Widget_ActionBar_TabBar = 16974068;
        public static final int Widget_ActionBar_TabText = 16974067;
        public static final int Widget_ActionBar_TabView = 16974066;
        public static final int Widget_ActionButton = 16973956;
        public static final int Widget_ActionButton_CloseMode = 16973960;
        public static final int Widget_ActionButton_Overflow = 16973959;
        public static final int Widget_AutoCompleteTextView = 16973863;
        public static final int Widget_Button = 16973844;
        public static final int Widget_Button_Inset = 16973845;
        public static final int Widget_Button_Small = 16973846;
        public static final int Widget_Button_Toggle = 16973847;
        public static final int Widget_CalendarView = 16974059;
        public static final int Widget_CompoundButton = 16973848;
        public static final int Widget_CompoundButton_CheckBox = 16973849;
        public static final int Widget_CompoundButton_RadioButton = 16973850;
        public static final int Widget_CompoundButton_Star = 16973851;
        public static final int Widget_DatePicker = 16974062;
        public static final int Widget_DeviceDefault = 16974144;
        public static final int Widget_DeviceDefault_ActionBar = 16974187;
        public static final int Widget_DeviceDefault_ActionBar_Solid = 16974195;
        public static final int Widget_DeviceDefault_ActionBar_TabBar = 16974194;
        public static final int Widget_DeviceDefault_ActionBar_TabText = 16974193;
        public static final int Widget_DeviceDefault_ActionBar_TabView = 16974192;
        public static final int Widget_DeviceDefault_ActionButton = 16974182;
        public static final int Widget_DeviceDefault_ActionButton_CloseMode = 16974186;
        public static final int Widget_DeviceDefault_ActionButton_Overflow = 16974183;
        public static final int Widget_DeviceDefault_ActionButton_TextButton = 16974184;
        public static final int Widget_DeviceDefault_ActionMode = 16974185;
        public static final int Widget_DeviceDefault_AutoCompleteTextView = 16974151;
        public static final int Widget_DeviceDefault_Button = 16974145;
        public static final int Widget_DeviceDefault_Button_Borderless = 16974188;
        public static final int Widget_DeviceDefault_Button_Borderless_Colored = 16974561;
        public static final int Widget_DeviceDefault_Button_Borderless_Small = 16974149;
        public static final int Widget_DeviceDefault_Button_Colored = 16974560;
        public static final int Widget_DeviceDefault_Button_Inset = 16974147;
        public static final int Widget_DeviceDefault_Button_Small = 16974146;
        public static final int Widget_DeviceDefault_Button_Toggle = 16974148;
        public static final int Widget_DeviceDefault_CalendarView = 16974190;
        public static final int Widget_DeviceDefault_CheckedTextView = 16974299;
        public static final int Widget_DeviceDefault_CompoundButton_CheckBox = 16974152;
        public static final int Widget_DeviceDefault_CompoundButton_RadioButton = 16974169;
        public static final int Widget_DeviceDefault_CompoundButton_Star = 16974173;
        public static final int Widget_DeviceDefault_DatePicker = 16974191;
        public static final int Widget_DeviceDefault_DropDownItem = 16974177;
        public static final int Widget_DeviceDefault_DropDownItem_Spinner = 16974178;
        public static final int Widget_DeviceDefault_EditText = 16974154;
        public static final int Widget_DeviceDefault_ExpandableListView = 16974155;
        public static final int Widget_DeviceDefault_FastScroll = 16974313;
        public static final int Widget_DeviceDefault_GridView = 16974156;
        public static final int Widget_DeviceDefault_HorizontalScrollView = 16974171;
        public static final int Widget_DeviceDefault_ImageButton = 16974157;
        public static final int Widget_DeviceDefault_Light = 16974196;
        public static final int Widget_DeviceDefault_Light_ActionBar = 16974243;
        public static final int Widget_DeviceDefault_Light_ActionBar_Solid = 16974247;
        /** @deprecated */
        @Deprecated
        public static final int Widget_DeviceDefault_Light_ActionBar_Solid_Inverse = 16974248;
        public static final int Widget_DeviceDefault_Light_ActionBar_TabBar = 16974246;
        /** @deprecated */
        @Deprecated
        public static final int Widget_DeviceDefault_Light_ActionBar_TabBar_Inverse = 16974249;
        public static final int Widget_DeviceDefault_Light_ActionBar_TabText = 16974245;
        /** @deprecated */
        @Deprecated
        public static final int Widget_DeviceDefault_Light_ActionBar_TabText_Inverse = 16974251;
        public static final int Widget_DeviceDefault_Light_ActionBar_TabView = 16974244;
        /** @deprecated */
        @Deprecated
        public static final int Widget_DeviceDefault_Light_ActionBar_TabView_Inverse = 16974250;
        public static final int Widget_DeviceDefault_Light_ActionButton = 16974239;
        public static final int Widget_DeviceDefault_Light_ActionButton_CloseMode = 16974242;
        public static final int Widget_DeviceDefault_Light_ActionButton_Overflow = 16974240;
        public static final int Widget_DeviceDefault_Light_ActionMode = 16974241;
        /** @deprecated */
        @Deprecated
        public static final int Widget_DeviceDefault_Light_ActionMode_Inverse = 16974252;
        public static final int Widget_DeviceDefault_Light_AutoCompleteTextView = 16974203;
        public static final int Widget_DeviceDefault_Light_Button = 16974197;
        public static final int Widget_DeviceDefault_Light_Button_Borderless_Small = 16974201;
        public static final int Widget_DeviceDefault_Light_Button_Inset = 16974199;
        public static final int Widget_DeviceDefault_Light_Button_Small = 16974198;
        public static final int Widget_DeviceDefault_Light_Button_Toggle = 16974200;
        public static final int Widget_DeviceDefault_Light_CalendarView = 16974238;
        public static final int Widget_DeviceDefault_Light_CheckedTextView = 16974300;
        public static final int Widget_DeviceDefault_Light_CompoundButton_CheckBox = 16974204;
        public static final int Widget_DeviceDefault_Light_CompoundButton_RadioButton = 16974224;
        public static final int Widget_DeviceDefault_Light_CompoundButton_Star = 16974228;
        public static final int Widget_DeviceDefault_Light_DropDownItem = 16974232;
        public static final int Widget_DeviceDefault_Light_DropDownItem_Spinner = 16974233;
        public static final int Widget_DeviceDefault_Light_EditText = 16974206;
        public static final int Widget_DeviceDefault_Light_ExpandableListView = 16974207;
        public static final int Widget_DeviceDefault_Light_FastScroll = 16974315;
        public static final int Widget_DeviceDefault_Light_GridView = 16974208;
        public static final int Widget_DeviceDefault_Light_HorizontalScrollView = 16974226;
        public static final int Widget_DeviceDefault_Light_ImageButton = 16974209;
        public static final int Widget_DeviceDefault_Light_ListPopupWindow = 16974235;
        public static final int Widget_DeviceDefault_Light_ListView = 16974210;
        public static final int Widget_DeviceDefault_Light_ListView_DropDown = 16974205;
        public static final int Widget_DeviceDefault_Light_MediaRouteButton = 16974296;
        public static final int Widget_DeviceDefault_Light_PopupMenu = 16974236;
        public static final int Widget_DeviceDefault_Light_PopupWindow = 16974211;
        public static final int Widget_DeviceDefault_Light_ProgressBar = 16974212;
        public static final int Widget_DeviceDefault_Light_ProgressBar_Horizontal = 16974213;
        public static final int Widget_DeviceDefault_Light_ProgressBar_Inverse = 16974217;
        public static final int Widget_DeviceDefault_Light_ProgressBar_Large = 16974216;
        public static final int Widget_DeviceDefault_Light_ProgressBar_Large_Inverse = 16974219;
        public static final int Widget_DeviceDefault_Light_ProgressBar_Small = 16974214;
        public static final int Widget_DeviceDefault_Light_ProgressBar_Small_Inverse = 16974218;
        public static final int Widget_DeviceDefault_Light_ProgressBar_Small_Title = 16974215;
        public static final int Widget_DeviceDefault_Light_RatingBar = 16974221;
        public static final int Widget_DeviceDefault_Light_RatingBar_Indicator = 16974222;
        public static final int Widget_DeviceDefault_Light_RatingBar_Small = 16974223;
        public static final int Widget_DeviceDefault_Light_ScrollView = 16974225;
        public static final int Widget_DeviceDefault_Light_SeekBar = 16974220;
        public static final int Widget_DeviceDefault_Light_Spinner = 16974227;
        public static final int Widget_DeviceDefault_Light_StackView = 16974316;
        public static final int Widget_DeviceDefault_Light_Tab = 16974237;
        public static final int Widget_DeviceDefault_Light_TabWidget = 16974229;
        public static final int Widget_DeviceDefault_Light_TextView = 16974202;
        public static final int Widget_DeviceDefault_Light_TextView_SpinnerItem = 16974234;
        public static final int Widget_DeviceDefault_Light_WebTextView = 16974230;
        public static final int Widget_DeviceDefault_Light_WebView = 16974231;
        public static final int Widget_DeviceDefault_ListPopupWindow = 16974180;
        public static final int Widget_DeviceDefault_ListView = 16974158;
        public static final int Widget_DeviceDefault_ListView_DropDown = 16974153;
        public static final int Widget_DeviceDefault_MediaRouteButton = 16974295;
        public static final int Widget_DeviceDefault_PopupMenu = 16974181;
        public static final int Widget_DeviceDefault_PopupWindow = 16974159;
        public static final int Widget_DeviceDefault_ProgressBar = 16974160;
        public static final int Widget_DeviceDefault_ProgressBar_Horizontal = 16974161;
        public static final int Widget_DeviceDefault_ProgressBar_Large = 16974164;
        public static final int Widget_DeviceDefault_ProgressBar_Small = 16974162;
        public static final int Widget_DeviceDefault_ProgressBar_Small_Title = 16974163;
        public static final int Widget_DeviceDefault_RatingBar = 16974166;
        public static final int Widget_DeviceDefault_RatingBar_Indicator = 16974167;
        public static final int Widget_DeviceDefault_RatingBar_Small = 16974168;
        public static final int Widget_DeviceDefault_ScrollView = 16974170;
        public static final int Widget_DeviceDefault_SeekBar = 16974165;
        public static final int Widget_DeviceDefault_Spinner = 16974172;
        public static final int Widget_DeviceDefault_StackView = 16974314;
        public static final int Widget_DeviceDefault_Tab = 16974189;
        public static final int Widget_DeviceDefault_TabWidget = 16974174;
        public static final int Widget_DeviceDefault_TextView = 16974150;
        public static final int Widget_DeviceDefault_TextView_SpinnerItem = 16974179;
        public static final int Widget_DeviceDefault_WebTextView = 16974175;
        public static final int Widget_DeviceDefault_WebView = 16974176;
        public static final int Widget_DropDownItem = 16973867;
        public static final int Widget_DropDownItem_Spinner = 16973868;
        public static final int Widget_EditText = 16973859;
        public static final int Widget_ExpandableListView = 16973860;
        public static final int Widget_FastScroll = 16974309;
        public static final int Widget_FragmentBreadCrumbs = 16973961;
        public static final int Widget_Gallery = 16973877;
        public static final int Widget_GridView = 16973874;
        public static final int Widget_Holo = 16973962;
        public static final int Widget_Holo_ActionBar = 16974004;
        public static final int Widget_Holo_ActionBar_Solid = 16974113;
        public static final int Widget_Holo_ActionBar_TabBar = 16974071;
        public static final int Widget_Holo_ActionBar_TabText = 16974070;
        public static final int Widget_Holo_ActionBar_TabView = 16974069;
        public static final int Widget_Holo_ActionButton = 16973999;
        public static final int Widget_Holo_ActionButton_CloseMode = 16974003;
        public static final int Widget_Holo_ActionButton_Overflow = 16974000;
        public static final int Widget_Holo_ActionButton_TextButton = 16974001;
        public static final int Widget_Holo_ActionMode = 16974002;
        public static final int Widget_Holo_AutoCompleteTextView = 16973968;
        public static final int Widget_Holo_Button = 16973963;
        public static final int Widget_Holo_Button_Borderless = 16974050;
        public static final int Widget_Holo_Button_Borderless_Small = 16974106;
        public static final int Widget_Holo_Button_Inset = 16973965;
        public static final int Widget_Holo_Button_Small = 16973964;
        public static final int Widget_Holo_Button_Toggle = 16973966;
        public static final int Widget_Holo_CalendarView = 16974060;
        public static final int Widget_Holo_CheckedTextView = 16974297;
        public static final int Widget_Holo_CompoundButton_CheckBox = 16973969;
        public static final int Widget_Holo_CompoundButton_RadioButton = 16973986;
        public static final int Widget_Holo_CompoundButton_Star = 16973990;
        public static final int Widget_Holo_DatePicker = 16974063;
        public static final int Widget_Holo_DropDownItem = 16973994;
        public static final int Widget_Holo_DropDownItem_Spinner = 16973995;
        public static final int Widget_Holo_EditText = 16973971;
        public static final int Widget_Holo_ExpandableListView = 16973972;
        public static final int Widget_Holo_GridView = 16973973;
        public static final int Widget_Holo_HorizontalScrollView = 16973988;
        public static final int Widget_Holo_ImageButton = 16973974;
        public static final int Widget_Holo_Light = 16974005;
        public static final int Widget_Holo_Light_ActionBar = 16974049;
        public static final int Widget_Holo_Light_ActionBar_Solid = 16974114;
        public static final int Widget_Holo_Light_ActionBar_Solid_Inverse = 16974115;
        public static final int Widget_Holo_Light_ActionBar_TabBar = 16974074;
        public static final int Widget_Holo_Light_ActionBar_TabBar_Inverse = 16974116;
        public static final int Widget_Holo_Light_ActionBar_TabText = 16974073;
        public static final int Widget_Holo_Light_ActionBar_TabText_Inverse = 16974118;
        public static final int Widget_Holo_Light_ActionBar_TabView = 16974072;
        public static final int Widget_Holo_Light_ActionBar_TabView_Inverse = 16974117;
        public static final int Widget_Holo_Light_ActionButton = 16974045;
        public static final int Widget_Holo_Light_ActionButton_CloseMode = 16974048;
        public static final int Widget_Holo_Light_ActionButton_Overflow = 16974046;
        public static final int Widget_Holo_Light_ActionMode = 16974047;
        public static final int Widget_Holo_Light_ActionMode_Inverse = 16974119;
        public static final int Widget_Holo_Light_AutoCompleteTextView = 16974011;
        public static final int Widget_Holo_Light_Button = 16974006;
        public static final int Widget_Holo_Light_Button_Borderless_Small = 16974107;
        public static final int Widget_Holo_Light_Button_Inset = 16974008;
        public static final int Widget_Holo_Light_Button_Small = 16974007;
        public static final int Widget_Holo_Light_Button_Toggle = 16974009;
        public static final int Widget_Holo_Light_CalendarView = 16974061;
        public static final int Widget_Holo_Light_CheckedTextView = 16974298;
        public static final int Widget_Holo_Light_CompoundButton_CheckBox = 16974012;
        public static final int Widget_Holo_Light_CompoundButton_RadioButton = 16974032;
        public static final int Widget_Holo_Light_CompoundButton_Star = 16974036;
        public static final int Widget_Holo_Light_DropDownItem = 16974040;
        public static final int Widget_Holo_Light_DropDownItem_Spinner = 16974041;
        public static final int Widget_Holo_Light_EditText = 16974014;
        public static final int Widget_Holo_Light_ExpandableListView = 16974015;
        public static final int Widget_Holo_Light_GridView = 16974016;
        public static final int Widget_Holo_Light_HorizontalScrollView = 16974034;
        public static final int Widget_Holo_Light_ImageButton = 16974017;
        public static final int Widget_Holo_Light_ListPopupWindow = 16974043;
        public static final int Widget_Holo_Light_ListView = 16974018;
        public static final int Widget_Holo_Light_ListView_DropDown = 16974013;
        public static final int Widget_Holo_Light_MediaRouteButton = 16974294;
        public static final int Widget_Holo_Light_PopupMenu = 16974044;
        public static final int Widget_Holo_Light_PopupWindow = 16974019;
        public static final int Widget_Holo_Light_ProgressBar = 16974020;
        public static final int Widget_Holo_Light_ProgressBar_Horizontal = 16974021;
        public static final int Widget_Holo_Light_ProgressBar_Inverse = 16974025;
        public static final int Widget_Holo_Light_ProgressBar_Large = 16974024;
        public static final int Widget_Holo_Light_ProgressBar_Large_Inverse = 16974027;
        public static final int Widget_Holo_Light_ProgressBar_Small = 16974022;
        public static final int Widget_Holo_Light_ProgressBar_Small_Inverse = 16974026;
        public static final int Widget_Holo_Light_ProgressBar_Small_Title = 16974023;
        public static final int Widget_Holo_Light_RatingBar = 16974029;
        public static final int Widget_Holo_Light_RatingBar_Indicator = 16974030;
        public static final int Widget_Holo_Light_RatingBar_Small = 16974031;
        public static final int Widget_Holo_Light_ScrollView = 16974033;
        public static final int Widget_Holo_Light_SeekBar = 16974028;
        public static final int Widget_Holo_Light_Spinner = 16974035;
        public static final int Widget_Holo_Light_Tab = 16974052;
        public static final int Widget_Holo_Light_TabWidget = 16974037;
        public static final int Widget_Holo_Light_TextView = 16974010;
        public static final int Widget_Holo_Light_TextView_SpinnerItem = 16974042;
        public static final int Widget_Holo_Light_WebTextView = 16974038;
        public static final int Widget_Holo_Light_WebView = 16974039;
        public static final int Widget_Holo_ListPopupWindow = 16973997;
        public static final int Widget_Holo_ListView = 16973975;
        public static final int Widget_Holo_ListView_DropDown = 16973970;
        public static final int Widget_Holo_MediaRouteButton = 16974293;
        public static final int Widget_Holo_PopupMenu = 16973998;
        public static final int Widget_Holo_PopupWindow = 16973976;
        public static final int Widget_Holo_ProgressBar = 16973977;
        public static final int Widget_Holo_ProgressBar_Horizontal = 16973978;
        public static final int Widget_Holo_ProgressBar_Large = 16973981;
        public static final int Widget_Holo_ProgressBar_Small = 16973979;
        public static final int Widget_Holo_ProgressBar_Small_Title = 16973980;
        public static final int Widget_Holo_RatingBar = 16973983;
        public static final int Widget_Holo_RatingBar_Indicator = 16973984;
        public static final int Widget_Holo_RatingBar_Small = 16973985;
        public static final int Widget_Holo_ScrollView = 16973987;
        public static final int Widget_Holo_SeekBar = 16973982;
        public static final int Widget_Holo_Spinner = 16973989;
        public static final int Widget_Holo_Tab = 16974051;
        public static final int Widget_Holo_TabWidget = 16973991;
        public static final int Widget_Holo_TextView = 16973967;
        public static final int Widget_Holo_TextView_SpinnerItem = 16973996;
        public static final int Widget_Holo_WebTextView = 16973992;
        public static final int Widget_Holo_WebView = 16973993;
        public static final int Widget_ImageButton = 16973862;
        public static final int Widget_ImageWell = 16973861;
        /** @deprecated */
        @Deprecated
        public static final int Widget_KeyboardView = 16973911;
        public static final int Widget_ListPopupWindow = 16973957;
        public static final int Widget_ListView = 16973870;
        public static final int Widget_ListView_DropDown = 16973872;
        public static final int Widget_ListView_Menu = 16973873;
        public static final int Widget_ListView_White = 16973871;
        public static final int Widget_Material = 16974413;
        public static final int Widget_Material_ActionBar = 16974414;
        public static final int Widget_Material_ActionBar_Solid = 16974415;
        public static final int Widget_Material_ActionBar_TabBar = 16974416;
        public static final int Widget_Material_ActionBar_TabText = 16974417;
        public static final int Widget_Material_ActionBar_TabView = 16974418;
        public static final int Widget_Material_ActionButton = 16974419;
        public static final int Widget_Material_ActionButton_CloseMode = 16974420;
        public static final int Widget_Material_ActionButton_Overflow = 16974421;
        public static final int Widget_Material_ActionMode = 16974422;
        public static final int Widget_Material_AutoCompleteTextView = 16974423;
        public static final int Widget_Material_Button = 16974424;
        public static final int Widget_Material_ButtonBar = 16974431;
        public static final int Widget_Material_ButtonBar_AlertDialog = 16974432;
        public static final int Widget_Material_Button_Borderless = 16974425;
        public static final int Widget_Material_Button_Borderless_Colored = 16974426;
        public static final int Widget_Material_Button_Borderless_Small = 16974427;
        public static final int Widget_Material_Button_Colored = 16974547;
        public static final int Widget_Material_Button_Inset = 16974428;
        public static final int Widget_Material_Button_Small = 16974429;
        public static final int Widget_Material_Button_Toggle = 16974430;
        public static final int Widget_Material_CalendarView = 16974433;
        public static final int Widget_Material_CheckedTextView = 16974434;
        public static final int Widget_Material_CompoundButton_CheckBox = 16974435;
        public static final int Widget_Material_CompoundButton_RadioButton = 16974436;
        public static final int Widget_Material_CompoundButton_Star = 16974437;
        public static final int Widget_Material_CompoundButton_Switch = 16974554;
        public static final int Widget_Material_DatePicker = 16974438;
        public static final int Widget_Material_DropDownItem = 16974439;
        public static final int Widget_Material_DropDownItem_Spinner = 16974440;
        public static final int Widget_Material_EditText = 16974441;
        public static final int Widget_Material_ExpandableListView = 16974442;
        public static final int Widget_Material_FastScroll = 16974443;
        public static final int Widget_Material_GridView = 16974444;
        public static final int Widget_Material_HorizontalScrollView = 16974445;
        public static final int Widget_Material_ImageButton = 16974446;
        public static final int Widget_Material_Light = 16974478;
        public static final int Widget_Material_Light_ActionBar = 16974479;
        public static final int Widget_Material_Light_ActionBar_Solid = 16974480;
        public static final int Widget_Material_Light_ActionBar_TabBar = 16974481;
        public static final int Widget_Material_Light_ActionBar_TabText = 16974482;
        public static final int Widget_Material_Light_ActionBar_TabView = 16974483;
        public static final int Widget_Material_Light_ActionButton = 16974484;
        public static final int Widget_Material_Light_ActionButton_CloseMode = 16974485;
        public static final int Widget_Material_Light_ActionButton_Overflow = 16974486;
        public static final int Widget_Material_Light_ActionMode = 16974487;
        public static final int Widget_Material_Light_AutoCompleteTextView = 16974488;
        public static final int Widget_Material_Light_Button = 16974489;
        public static final int Widget_Material_Light_ButtonBar = 16974496;
        public static final int Widget_Material_Light_ButtonBar_AlertDialog = 16974497;
        public static final int Widget_Material_Light_Button_Borderless = 16974490;
        public static final int Widget_Material_Light_Button_Borderless_Colored = 16974491;
        public static final int Widget_Material_Light_Button_Borderless_Small = 16974492;
        public static final int Widget_Material_Light_Button_Inset = 16974493;
        public static final int Widget_Material_Light_Button_Small = 16974494;
        public static final int Widget_Material_Light_Button_Toggle = 16974495;
        public static final int Widget_Material_Light_CalendarView = 16974498;
        public static final int Widget_Material_Light_CheckedTextView = 16974499;
        public static final int Widget_Material_Light_CompoundButton_CheckBox = 16974500;
        public static final int Widget_Material_Light_CompoundButton_RadioButton = 16974501;
        public static final int Widget_Material_Light_CompoundButton_Star = 16974502;
        public static final int Widget_Material_Light_CompoundButton_Switch = 16974555;
        public static final int Widget_Material_Light_DatePicker = 16974503;
        public static final int Widget_Material_Light_DropDownItem = 16974504;
        public static final int Widget_Material_Light_DropDownItem_Spinner = 16974505;
        public static final int Widget_Material_Light_EditText = 16974506;
        public static final int Widget_Material_Light_ExpandableListView = 16974507;
        public static final int Widget_Material_Light_FastScroll = 16974508;
        public static final int Widget_Material_Light_GridView = 16974509;
        public static final int Widget_Material_Light_HorizontalScrollView = 16974510;
        public static final int Widget_Material_Light_ImageButton = 16974511;
        public static final int Widget_Material_Light_ListPopupWindow = 16974512;
        public static final int Widget_Material_Light_ListView = 16974513;
        public static final int Widget_Material_Light_ListView_DropDown = 16974514;
        public static final int Widget_Material_Light_MediaRouteButton = 16974515;
        public static final int Widget_Material_Light_NumberPicker = 16974557;
        public static final int Widget_Material_Light_PopupMenu = 16974516;
        public static final int Widget_Material_Light_PopupMenu_Overflow = 16974517;
        public static final int Widget_Material_Light_PopupWindow = 16974518;
        public static final int Widget_Material_Light_ProgressBar = 16974519;
        public static final int Widget_Material_Light_ProgressBar_Horizontal = 16974520;
        public static final int Widget_Material_Light_ProgressBar_Inverse = 16974521;
        public static final int Widget_Material_Light_ProgressBar_Large = 16974522;
        public static final int Widget_Material_Light_ProgressBar_Large_Inverse = 16974523;
        public static final int Widget_Material_Light_ProgressBar_Small = 16974524;
        public static final int Widget_Material_Light_ProgressBar_Small_Inverse = 16974525;
        public static final int Widget_Material_Light_ProgressBar_Small_Title = 16974526;
        public static final int Widget_Material_Light_RatingBar = 16974527;
        public static final int Widget_Material_Light_RatingBar_Indicator = 16974528;
        public static final int Widget_Material_Light_RatingBar_Small = 16974529;
        public static final int Widget_Material_Light_ScrollView = 16974530;
        public static final int Widget_Material_Light_SearchView = 16974531;
        public static final int Widget_Material_Light_SeekBar = 16974532;
        public static final int Widget_Material_Light_SegmentedButton = 16974533;
        public static final int Widget_Material_Light_Spinner = 16974535;
        public static final int Widget_Material_Light_Spinner_Underlined = 16974536;
        public static final int Widget_Material_Light_StackView = 16974534;
        public static final int Widget_Material_Light_Tab = 16974537;
        public static final int Widget_Material_Light_TabWidget = 16974538;
        public static final int Widget_Material_Light_TextView = 16974539;
        public static final int Widget_Material_Light_TextView_SpinnerItem = 16974540;
        public static final int Widget_Material_Light_TimePicker = 16974541;
        public static final int Widget_Material_Light_WebTextView = 16974542;
        public static final int Widget_Material_Light_WebView = 16974543;
        public static final int Widget_Material_ListPopupWindow = 16974447;
        public static final int Widget_Material_ListView = 16974448;
        public static final int Widget_Material_ListView_DropDown = 16974449;
        public static final int Widget_Material_MediaRouteButton = 16974450;
        public static final int Widget_Material_NumberPicker = 16974556;
        public static final int Widget_Material_PopupMenu = 16974451;
        public static final int Widget_Material_PopupMenu_Overflow = 16974452;
        public static final int Widget_Material_PopupWindow = 16974453;
        public static final int Widget_Material_ProgressBar = 16974454;
        public static final int Widget_Material_ProgressBar_Horizontal = 16974455;
        public static final int Widget_Material_ProgressBar_Large = 16974456;
        public static final int Widget_Material_ProgressBar_Small = 16974457;
        public static final int Widget_Material_ProgressBar_Small_Title = 16974458;
        public static final int Widget_Material_RatingBar = 16974459;
        public static final int Widget_Material_RatingBar_Indicator = 16974460;
        public static final int Widget_Material_RatingBar_Small = 16974461;
        public static final int Widget_Material_ScrollView = 16974462;
        public static final int Widget_Material_SearchView = 16974463;
        public static final int Widget_Material_SeekBar = 16974464;
        public static final int Widget_Material_SeekBar_Discrete = 16974553;
        public static final int Widget_Material_SegmentedButton = 16974465;
        public static final int Widget_Material_Spinner = 16974467;
        public static final int Widget_Material_Spinner_Underlined = 16974468;
        public static final int Widget_Material_StackView = 16974466;
        public static final int Widget_Material_Tab = 16974469;
        public static final int Widget_Material_TabWidget = 16974470;
        public static final int Widget_Material_TextView = 16974471;
        public static final int Widget_Material_TextView_SpinnerItem = 16974472;
        public static final int Widget_Material_TimePicker = 16974473;
        public static final int Widget_Material_Toolbar = 16974474;
        public static final int Widget_Material_Toolbar_Button_Navigation = 16974475;
        public static final int Widget_Material_WebTextView = 16974476;
        public static final int Widget_Material_WebView = 16974477;
        public static final int Widget_PopupMenu = 16973958;
        public static final int Widget_PopupWindow = 16973878;
        public static final int Widget_ProgressBar = 16973852;
        public static final int Widget_ProgressBar_Horizontal = 16973855;
        public static final int Widget_ProgressBar_Inverse = 16973915;
        public static final int Widget_ProgressBar_Large = 16973853;
        public static final int Widget_ProgressBar_Large_Inverse = 16973916;
        public static final int Widget_ProgressBar_Small = 16973854;
        public static final int Widget_ProgressBar_Small_Inverse = 16973917;
        public static final int Widget_RatingBar = 16973857;
        public static final int Widget_ScrollView = 16973869;
        public static final int Widget_SeekBar = 16973856;
        public static final int Widget_Spinner = 16973864;
        public static final int Widget_Spinner_DropDown = 16973955;
        public static final int Widget_StackView = 16974310;
        public static final int Widget_TabWidget = 16973876;
        public static final int Widget_TextView = 16973858;
        public static final int Widget_TextView_PopupMenu = 16973865;
        public static final int Widget_TextView_SpinnerItem = 16973866;
        public static final int Widget_Toolbar = 16974311;
        public static final int Widget_Toolbar_Button_Navigation = 16974312;
        public static final int Widget_WebView = 16973875;

        public style() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class string {
        public static final int VideoView_error_button = 17039376;
        public static final int VideoView_error_text_invalid_progressive_playback = 17039381;
        public static final int VideoView_error_text_unknown = 17039377;
        public static final int VideoView_error_title = 17039378;
        public static final int autofill = 17039386;
        public static final int cancel = 17039360;
        public static final int copy = 17039361;
        public static final int copyUrl = 17039362;
        public static final int cut = 17039363;
        public static final int defaultMsisdnAlphaTag = 17039365;
        public static final int defaultVoiceMailAlphaTag = 17039364;
        public static final int dialog_alert_title = 17039380;
        public static final int emptyPhoneNumber = 17039366;
        public static final int fingerprint_icon_content_description = 17039384;
        public static final int httpErrorBadUrl = 17039367;
        public static final int httpErrorUnsupportedScheme = 17039368;
        public static final int no = 17039369;
        public static final int ok = 17039370;
        public static final int paste = 17039371;
        public static final int paste_as_plain_text = 17039385;
        public static final int search_go = 17039372;
        public static final int selectAll = 17039373;
        public static final int selectTextMode = 17039382;
        public static final int status_bar_notification_info_overflow = 17039383;
        public static final int unknownName = 17039374;
        public static final int untitled = 17039375;
        public static final int yes = 17039379;

        public string() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class raw {
        public raw() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class plurals {
        public plurals() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class mipmap {
        public static final int sym_def_app_icon = 17629184;

        public mipmap() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class menu {
        public menu() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class layout {
        public static final int activity_list_item = 17367040;
        public static final int browser_link_context_header = 17367054;
        public static final int expandable_list_content = 17367041;
        public static final int list_content = 17367060;
        public static final int preference_category = 17367042;
        public static final int select_dialog_item = 17367057;
        public static final int select_dialog_multichoice = 17367059;
        public static final int select_dialog_singlechoice = 17367058;
        public static final int simple_dropdown_item_1line = 17367050;
        public static final int simple_expandable_list_item_1 = 17367046;
        public static final int simple_expandable_list_item_2 = 17367047;
        public static final int simple_gallery_item = 17367051;
        public static final int simple_list_item_1 = 17367043;
        public static final int simple_list_item_2 = 17367044;
        public static final int simple_list_item_activated_1 = 17367062;
        public static final int simple_list_item_activated_2 = 17367063;
        public static final int simple_list_item_checked = 17367045;
        public static final int simple_list_item_multiple_choice = 17367056;
        public static final int simple_list_item_single_choice = 17367055;
        public static final int simple_selectable_list_item = 17367061;
        public static final int simple_spinner_dropdown_item = 17367049;
        public static final int simple_spinner_item = 17367048;
        public static final int test_list_item = 17367052;
        public static final int two_line_list_item = 17367053;

        public layout() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class interpolator {
        public static final int accelerate_cubic = 17563650;
        public static final int accelerate_decelerate = 17563654;
        public static final int accelerate_quad = 17563648;
        public static final int accelerate_quint = 17563652;
        public static final int anticipate = 17563655;
        public static final int anticipate_overshoot = 17563657;
        public static final int bounce = 17563658;
        public static final int cycle = 17563660;
        public static final int decelerate_cubic = 17563651;
        public static final int decelerate_quad = 17563649;
        public static final int decelerate_quint = 17563653;
        public static final int fast_out_extra_slow_in = 17563674;
        public static final int fast_out_linear_in = 17563663;
        public static final int fast_out_slow_in = 17563661;
        public static final int linear = 17563659;
        public static final int linear_out_slow_in = 17563662;
        public static final int overshoot = 17563656;

        public interpolator() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class integer {
        public static final int config_longAnimTime = 17694722;
        public static final int config_mediumAnimTime = 17694721;
        public static final int config_shortAnimTime = 17694720;
        public static final int status_bar_notification_info_maxnum = 17694723;

        public integer() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class id {
        public static final int accessibilityActionContextClick = 16908348;
        public static final int accessibilityActionHideTooltip = 16908357;
        public static final int accessibilityActionMoveWindow = 16908354;
        public static final int accessibilityActionPageDown = 16908359;
        public static final int accessibilityActionPageLeft = 16908360;
        public static final int accessibilityActionPageRight = 16908361;
        public static final int accessibilityActionPageUp = 16908358;
        public static final int accessibilityActionScrollDown = 16908346;
        public static final int accessibilityActionScrollLeft = 16908345;
        public static final int accessibilityActionScrollRight = 16908347;
        public static final int accessibilityActionScrollToPosition = 16908343;
        public static final int accessibilityActionScrollUp = 16908344;
        public static final int accessibilityActionSetProgress = 16908349;
        public static final int accessibilityActionShowOnScreen = 16908342;
        public static final int accessibilityActionShowTooltip = 16908356;
        public static final int addToDictionary = 16908330;
        public static final int autofill = 16908355;
        public static final int background = 16908288;
        public static final int button1 = 16908313;
        public static final int button2 = 16908314;
        public static final int button3 = 16908315;
        public static final int candidatesArea = 16908317;
        public static final int checkbox = 16908289;
        public static final int closeButton = 16908327;
        public static final int content = 16908290;
        public static final int copy = 16908321;
        public static final int copyUrl = 16908323;
        public static final int custom = 16908331;
        public static final int cut = 16908320;
        public static final int edit = 16908291;
        public static final int empty = 16908292;
        public static final int extractArea = 16908316;
        public static final int hint = 16908293;
        public static final int home = 16908332;
        public static final int icon = 16908294;
        public static final int icon1 = 16908295;
        public static final int icon2 = 16908296;
        public static final int icon_frame = 16908350;
        public static final int input = 16908297;
        public static final int inputArea = 16908318;
        public static final int inputExtractEditText = 16908325;
        /** @deprecated */
        @Deprecated
        public static final int keyboardView = 16908326;
        public static final int list = 16908298;
        public static final int list_container = 16908351;
        public static final int mask = 16908334;
        public static final int message = 16908299;
        public static final int navigationBarBackground = 16908336;
        public static final int paste = 16908322;
        public static final int pasteAsPlainText = 16908337;
        public static final int primary = 16908300;
        public static final int progress = 16908301;
        public static final int redo = 16908339;
        public static final int replaceText = 16908340;
        public static final int secondaryProgress = 16908303;
        public static final int selectAll = 16908319;
        public static final int selectTextMode = 16908333;
        public static final int selectedIcon = 16908302;
        public static final int shareText = 16908341;
        public static final int startSelectingText = 16908328;
        public static final int statusBarBackground = 16908335;
        public static final int stopSelectingText = 16908329;
        public static final int summary = 16908304;
        public static final int switchInputMethod = 16908324;
        public static final int switch_widget = 16908352;
        public static final int tabcontent = 16908305;
        public static final int tabhost = 16908306;
        public static final int tabs = 16908307;
        public static final int text1 = 16908308;
        public static final int text2 = 16908309;
        public static final int textAssist = 16908353;
        public static final int title = 16908310;
        public static final int toggle = 16908311;
        public static final int undo = 16908338;
        public static final int widget_frame = 16908312;

        public id() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class fraction {
        public fraction() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class drawable {
        public static final int alert_dark_frame = 17301504;
        public static final int alert_light_frame = 17301505;
        public static final int arrow_down_float = 17301506;
        public static final int arrow_up_float = 17301507;
        public static final int bottom_bar = 17301658;
        public static final int btn_default = 17301508;
        public static final int btn_default_small = 17301509;
        public static final int btn_dialog = 17301527;
        public static final int btn_dropdown = 17301510;
        public static final int btn_minus = 17301511;
        public static final int btn_plus = 17301512;
        public static final int btn_radio = 17301513;
        public static final int btn_star = 17301514;
        public static final int btn_star_big_off = 17301515;
        public static final int btn_star_big_on = 17301516;
        public static final int button_onoff_indicator_off = 17301518;
        public static final int button_onoff_indicator_on = 17301517;
        public static final int checkbox_off_background = 17301519;
        public static final int checkbox_on_background = 17301520;
        public static final int dark_header = 17301669;
        public static final int dialog_frame = 17301521;
        public static final int dialog_holo_dark_frame = 17301682;
        public static final int dialog_holo_light_frame = 17301683;
        public static final int divider_horizontal_bright = 17301522;
        public static final int divider_horizontal_dark = 17301524;
        public static final int divider_horizontal_dim_dark = 17301525;
        public static final int divider_horizontal_textfield = 17301523;
        public static final int edit_text = 17301526;
        public static final int editbox_background = 17301528;
        public static final int editbox_background_normal = 17301529;
        public static final int editbox_dropdown_dark_frame = 17301530;
        public static final int editbox_dropdown_light_frame = 17301531;
        public static final int gallery_thumb = 17301532;
        public static final int ic_btn_speak_now = 17301668;
        public static final int ic_delete = 17301533;
        public static final int ic_dialog_alert = 17301543;
        public static final int ic_dialog_dialer = 17301544;
        public static final int ic_dialog_email = 17301545;
        public static final int ic_dialog_info = 17301659;
        public static final int ic_dialog_map = 17301546;
        public static final int ic_input_add = 17301547;
        public static final int ic_input_delete = 17301548;
        public static final int ic_input_get = 17301549;
        public static final int ic_lock_idle_alarm = 17301550;
        public static final int ic_lock_idle_charging = 17301534;
        public static final int ic_lock_idle_lock = 17301535;
        public static final int ic_lock_idle_low_battery = 17301536;
        public static final int ic_lock_lock = 17301551;
        public static final int ic_lock_power_off = 17301552;
        public static final int ic_lock_silent_mode = 17301553;
        public static final int ic_lock_silent_mode_off = 17301554;
        public static final int ic_media_ff = 17301537;
        public static final int ic_media_next = 17301538;
        public static final int ic_media_pause = 17301539;
        public static final int ic_media_play = 17301540;
        public static final int ic_media_previous = 17301541;
        public static final int ic_media_rew = 17301542;
        public static final int ic_menu_add = 17301555;
        public static final int ic_menu_agenda = 17301556;
        public static final int ic_menu_always_landscape_portrait = 17301557;
        public static final int ic_menu_call = 17301558;
        public static final int ic_menu_camera = 17301559;
        public static final int ic_menu_close_clear_cancel = 17301560;
        public static final int ic_menu_compass = 17301561;
        public static final int ic_menu_crop = 17301562;
        public static final int ic_menu_day = 17301563;
        public static final int ic_menu_delete = 17301564;
        public static final int ic_menu_directions = 17301565;
        public static final int ic_menu_edit = 17301566;
        public static final int ic_menu_gallery = 17301567;
        public static final int ic_menu_help = 17301568;
        public static final int ic_menu_info_details = 17301569;
        public static final int ic_menu_manage = 17301570;
        public static final int ic_menu_mapmode = 17301571;
        public static final int ic_menu_month = 17301572;
        public static final int ic_menu_more = 17301573;
        public static final int ic_menu_my_calendar = 17301574;
        public static final int ic_menu_mylocation = 17301575;
        public static final int ic_menu_myplaces = 17301576;
        public static final int ic_menu_preferences = 17301577;
        public static final int ic_menu_recent_history = 17301578;
        public static final int ic_menu_report_image = 17301579;
        public static final int ic_menu_revert = 17301580;
        public static final int ic_menu_rotate = 17301581;
        public static final int ic_menu_save = 17301582;
        public static final int ic_menu_search = 17301583;
        public static final int ic_menu_send = 17301584;
        public static final int ic_menu_set_as = 17301585;
        public static final int ic_menu_share = 17301586;
        public static final int ic_menu_slideshow = 17301587;
        public static final int ic_menu_sort_alphabetically = 17301660;
        public static final int ic_menu_sort_by_size = 17301661;
        public static final int ic_menu_today = 17301588;
        public static final int ic_menu_upload = 17301589;
        public static final int ic_menu_upload_you_tube = 17301590;
        public static final int ic_menu_view = 17301591;
        public static final int ic_menu_week = 17301592;
        public static final int ic_menu_zoom = 17301593;
        public static final int ic_notification_clear_all = 17301594;
        public static final int ic_notification_overlay = 17301595;
        public static final int ic_partial_secure = 17301596;
        public static final int ic_popup_disk_full = 17301597;
        public static final int ic_popup_reminder = 17301598;
        public static final int ic_popup_sync = 17301599;
        public static final int ic_search_category_default = 17301600;
        public static final int ic_secure = 17301601;
        public static final int list_selector_background = 17301602;
        public static final int menu_frame = 17301603;
        public static final int menu_full_frame = 17301604;
        public static final int menuitem_background = 17301605;
        public static final int picture_frame = 17301606;
        public static final int presence_audio_away = 17301679;
        public static final int presence_audio_busy = 17301680;
        public static final int presence_audio_online = 17301681;
        public static final int presence_away = 17301607;
        public static final int presence_busy = 17301608;
        public static final int presence_invisible = 17301609;
        public static final int presence_offline = 17301610;
        public static final int presence_online = 17301611;
        public static final int presence_video_away = 17301676;
        public static final int presence_video_busy = 17301677;
        public static final int presence_video_online = 17301678;
        public static final int progress_horizontal = 17301612;
        public static final int progress_indeterminate_horizontal = 17301613;
        public static final int radiobutton_off_background = 17301614;
        public static final int radiobutton_on_background = 17301615;
        public static final int screen_background_dark = 17301656;
        public static final int screen_background_dark_transparent = 17301673;
        public static final int screen_background_light = 17301657;
        public static final int screen_background_light_transparent = 17301674;
        public static final int spinner_background = 17301616;
        public static final int spinner_dropdown_background = 17301617;
        public static final int star_big_off = 17301619;
        public static final int star_big_on = 17301618;
        public static final int star_off = 17301621;
        public static final int star_on = 17301620;
        public static final int stat_notify_call_mute = 17301622;
        public static final int stat_notify_chat = 17301623;
        public static final int stat_notify_error = 17301624;
        public static final int stat_notify_missed_call = 17301631;
        public static final int stat_notify_more = 17301625;
        public static final int stat_notify_sdcard = 17301626;
        public static final int stat_notify_sdcard_prepare = 17301675;
        public static final int stat_notify_sdcard_usb = 17301627;
        public static final int stat_notify_sync = 17301628;
        public static final int stat_notify_sync_noanim = 17301629;
        public static final int stat_notify_voicemail = 17301630;
        public static final int stat_sys_data_bluetooth = 17301632;
        public static final int stat_sys_download = 17301633;
        public static final int stat_sys_download_done = 17301634;
        public static final int stat_sys_headset = 17301635;
        /** @deprecated */
        @Deprecated
        public static final int stat_sys_phone_call = 17301636;
        /** @deprecated */
        @Deprecated
        public static final int stat_sys_phone_call_forward = 17301637;
        /** @deprecated */
        @Deprecated
        public static final int stat_sys_phone_call_on_hold = 17301638;
        public static final int stat_sys_speakerphone = 17301639;
        public static final int stat_sys_upload = 17301640;
        public static final int stat_sys_upload_done = 17301641;
        /** @deprecated */
        @Deprecated
        public static final int stat_sys_vp_phone_call = 17301671;
        /** @deprecated */
        @Deprecated
        public static final int stat_sys_vp_phone_call_on_hold = 17301672;
        public static final int stat_sys_warning = 17301642;
        public static final int status_bar_item_app_background = 17301643;
        public static final int status_bar_item_background = 17301644;
        public static final int sym_action_call = 17301645;
        public static final int sym_action_chat = 17301646;
        public static final int sym_action_email = 17301647;
        public static final int sym_call_incoming = 17301648;
        public static final int sym_call_missed = 17301649;
        public static final int sym_call_outgoing = 17301650;
        public static final int sym_contact_card = 17301652;
        public static final int sym_def_app_icon = 17301651;
        public static final int title_bar = 17301653;
        public static final int title_bar_tall = 17301670;
        public static final int toast_frame = 17301654;
        public static final int zoom_plate = 17301655;

        public drawable() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class dimen {
        public static final int app_icon_size = 17104896;
        public static final int dialog_min_width_major = 17104899;
        public static final int dialog_min_width_minor = 17104900;
        public static final int notification_large_icon_height = 17104902;
        public static final int notification_large_icon_width = 17104901;
        public static final int thumbnail_height = 17104897;
        public static final int thumbnail_width = 17104898;

        public dimen() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class color {
        public static final int background_dark = 17170446;
        public static final int background_light = 17170447;
        public static final int black = 17170444;
        public static final int darker_gray = 17170432;
        public static final int holo_blue_bright = 17170459;
        public static final int holo_blue_dark = 17170451;
        public static final int holo_blue_light = 17170450;
        public static final int holo_green_dark = 17170453;
        public static final int holo_green_light = 17170452;
        public static final int holo_orange_dark = 17170457;
        public static final int holo_orange_light = 17170456;
        public static final int holo_purple = 17170458;
        public static final int holo_red_dark = 17170455;
        public static final int holo_red_light = 17170454;
        /** @deprecated */
        @Deprecated
        public static final int primary_text_dark = 17170433;
        /** @deprecated */
        @Deprecated
        public static final int primary_text_dark_nodisable = 17170434;
        /** @deprecated */
        @Deprecated
        public static final int primary_text_light = 17170435;
        /** @deprecated */
        @Deprecated
        public static final int primary_text_light_nodisable = 17170436;
        /** @deprecated */
        @Deprecated
        public static final int secondary_text_dark = 17170437;
        /** @deprecated */
        @Deprecated
        public static final int secondary_text_dark_nodisable = 17170438;
        /** @deprecated */
        @Deprecated
        public static final int secondary_text_light = 17170439;
        /** @deprecated */
        @Deprecated
        public static final int secondary_text_light_nodisable = 17170440;
        public static final int tab_indicator_text = 17170441;
        /** @deprecated */
        @Deprecated
        public static final int tertiary_text_dark = 17170448;
        /** @deprecated */
        @Deprecated
        public static final int tertiary_text_light = 17170449;
        public static final int transparent = 17170445;
        public static final int white = 17170443;
        public static final int widget_edittext_dark = 17170442;

        public color() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class bool {
        public bool() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class attr {
        public static final int absListViewStyle = 16842858;
        public static final int accessibilityEventTypes = 16843648;
        public static final int accessibilityFeedbackType = 16843650;
        public static final int accessibilityFlags = 16843652;
        public static final int accessibilityHeading = 16844160;
        public static final int accessibilityLiveRegion = 16843758;
        public static final int accessibilityPaneTitle = 16844156;
        public static final int accessibilityTraversalAfter = 16843986;
        public static final int accessibilityTraversalBefore = 16843985;
        public static final int accountPreferences = 16843423;
        public static final int accountType = 16843407;
        public static final int action = 16842797;
        public static final int actionBarDivider = 16843675;
        public static final int actionBarItemBackground = 16843676;
        public static final int actionBarPopupTheme = 16843917;
        public static final int actionBarSize = 16843499;
        public static final int actionBarSplitStyle = 16843656;
        public static final int actionBarStyle = 16843470;
        public static final int actionBarTabBarStyle = 16843508;
        public static final int actionBarTabStyle = 16843507;
        public static final int actionBarTabTextStyle = 16843509;
        public static final int actionBarTheme = 16843825;
        public static final int actionBarWidgetTheme = 16843671;
        public static final int actionButtonStyle = 16843480;
        public static final int actionDropDownStyle = 16843479;
        public static final int actionLayout = 16843515;
        public static final int actionMenuTextAppearance = 16843616;
        public static final int actionMenuTextColor = 16843617;
        public static final int actionModeBackground = 16843483;
        public static final int actionModeCloseButtonStyle = 16843511;
        public static final int actionModeCloseDrawable = 16843484;
        public static final int actionModeCopyDrawable = 16843538;
        public static final int actionModeCutDrawable = 16843537;
        public static final int actionModeFindDrawable = 16843898;
        public static final int actionModePasteDrawable = 16843539;
        public static final int actionModeSelectAllDrawable = 16843646;
        public static final int actionModeShareDrawable = 16843897;
        public static final int actionModeSplitBackground = 16843677;
        public static final int actionModeStyle = 16843668;
        public static final int actionModeWebSearchDrawable = 16843899;
        public static final int actionOverflowButtonStyle = 16843510;
        public static final int actionOverflowMenuStyle = 16843844;
        public static final int actionProviderClass = 16843657;
        public static final int actionViewClass = 16843516;
        public static final int activatedBackgroundIndicator = 16843517;
        public static final int activityCloseEnterAnimation = 16842938;
        public static final int activityCloseExitAnimation = 16842939;
        public static final int activityOpenEnterAnimation = 16842936;
        public static final int activityOpenExitAnimation = 16842937;
        public static final int addPrintersActivity = 16843750;
        public static final int addStatesFromChildren = 16842992;
        public static final int adjustViewBounds = 16843038;
        public static final int advancedPrintOptionsActivity = 16843761;
        public static final int alertDialogIcon = 16843605;
        public static final int alertDialogStyle = 16842845;
        public static final int alertDialogTheme = 16843529;
        public static final int alignmentMode = 16843642;
        public static final int allContactsName = 16843468;
        public static final int allowAudioPlaybackCapture = 16844289;
        public static final int allowBackup = 16843392;
        public static final int allowClearUserData = 16842757;
        public static final int allowEmbedded = 16843765;
        public static final int allowParallelSyncs = 16843570;
        public static final int allowSingleTap = 16843353;
        public static final int allowTaskReparenting = 16843268;
        public static final int allowUndo = 16843999;
        public static final int alpha = 16843551;
        public static final int alphabeticModifiers = 16844110;
        public static final int alphabeticShortcut = 16843235;
        public static final int alwaysDrawnWithCache = 16842991;
        public static final int alwaysRetainTaskState = 16843267;
        /** @deprecated */
        @Deprecated
        public static final int amPmBackgroundColor = 16843941;
        /** @deprecated */
        @Deprecated
        public static final int amPmTextColor = 16843940;
        public static final int ambientShadowAlpha = 16843966;
        public static final int angle = 16843168;
        public static final int animateFirstView = 16843477;
        public static final int animateLayoutChanges = 16843506;
        public static final int animateOnClick = 16843356;
        public static final int animation = 16843213;
        public static final int animationCache = 16842989;
        public static final int animationDuration = 16843026;
        public static final int animationOrder = 16843214;
        /** @deprecated */
        @Deprecated
        public static final int animationResolution = 16843546;
        public static final int antialias = 16843034;
        public static final int anyDensity = 16843372;
        public static final int apduServiceBanner = 16843757;
        public static final int apiKey = 16843281;
        public static final int appCategory = 16844101;
        public static final int appComponentFactory = 16844154;
        public static final int author = 16843444;
        public static final int authorities = 16842776;
        public static final int autoAdvanceViewId = 16843535;
        public static final int autoCompleteTextViewStyle = 16842859;
        public static final int autoLink = 16842928;
        public static final int autoMirrored = 16843754;
        public static final int autoRemoveFromRecents = 16843847;
        public static final int autoSizeMaxTextSize = 16844102;
        public static final int autoSizeMinTextSize = 16844088;
        public static final int autoSizePresetSizes = 16844087;
        public static final int autoSizeStepGranularity = 16844086;
        public static final int autoSizeTextType = 16844085;
        public static final int autoStart = 16843445;
        /** @deprecated */
        @Deprecated
        public static final int autoText = 16843114;
        public static final int autoUrlDetect = 16843404;
        public static final int autoVerify = 16844014;
        public static final int autofillHints = 16844118;
        public static final int autofilledHighlight = 16844136;
        public static final int background = 16842964;
        public static final int backgroundDimAmount = 16842802;
        public static final int backgroundDimEnabled = 16843295;
        public static final int backgroundSplit = 16843659;
        public static final int backgroundStacked = 16843658;
        public static final int backgroundTint = 16843883;
        public static final int backgroundTintMode = 16843884;
        public static final int backupAgent = 16843391;
        public static final int backupInForeground = 16844058;
        public static final int banner = 16843762;
        public static final int baseline = 16843548;
        public static final int baselineAlignBottom = 16843042;
        public static final int baselineAligned = 16843046;
        public static final int baselineAlignedChildIndex = 16843047;
        public static final int bitmap = 16844054;
        public static final int borderlessButtonStyle = 16843563;
        public static final int bottom = 16843184;
        public static final int bottomBright = 16842957;
        public static final int bottomDark = 16842953;
        public static final int bottomLeftRadius = 16843179;
        public static final int bottomMedium = 16842958;
        public static final int bottomOffset = 16843351;
        public static final int bottomRightRadius = 16843180;
        public static final int breadCrumbShortTitle = 16843524;
        public static final int breadCrumbTitle = 16843523;
        public static final int breakStrategy = 16843997;
        public static final int bufferType = 16843086;
        public static final int button = 16843015;
        public static final int buttonBarButtonStyle = 16843567;
        public static final int buttonBarNegativeButtonStyle = 16843915;
        public static final int buttonBarNeutralButtonStyle = 16843914;
        public static final int buttonBarPositiveButtonStyle = 16843913;
        public static final int buttonBarStyle = 16843566;
        public static final int buttonCornerRadius = 16844149;
        public static final int buttonGravity = 16844030;
        public static final int buttonStyle = 16842824;
        public static final int buttonStyleInset = 16842826;
        public static final int buttonStyleSmall = 16842825;
        public static final int buttonStyleToggle = 16842827;
        public static final int buttonTint = 16843887;
        public static final int buttonTintMode = 16843888;
        public static final int cacheColorHint = 16843009;
        public static final int calendarTextColor = 16843931;
        public static final int calendarViewShown = 16843596;
        public static final int calendarViewStyle = 16843613;
        public static final int canControlMagnification = 16844039;
        public static final int canPerformGestures = 16844045;
        public static final int canRecord = 16844060;
        /** @deprecated */
        @Deprecated
        public static final int canRequestEnhancedWebAccessibility = 16843736;
        public static final int canRequestFilterKeyEvents = 16843737;
        public static final int canRequestFingerprintGestures = 16844109;
        public static final int canRequestTouchExplorationMode = 16843735;
        public static final int canRetrieveWindowContent = 16843653;
        public static final int candidatesTextStyleSpans = 16843312;
        public static final int cantSaveState = 16844142;
        /** @deprecated */
        @Deprecated
        public static final int capitalize = 16843113;
        public static final int category = 16843752;
        public static final int centerBright = 16842956;
        public static final int centerColor = 16843275;
        public static final int centerDark = 16842952;
        public static final int centerMedium = 16842959;
        public static final int centerX = 16843170;
        public static final int centerY = 16843171;
        public static final int certDigest = 16844104;
        public static final int checkBoxPreferenceStyle = 16842895;
        public static final int checkMark = 16843016;
        public static final int checkMarkTint = 16843943;
        public static final int checkMarkTintMode = 16843944;
        public static final int checkable = 16843237;
        public static final int checkableBehavior = 16843232;
        public static final int checkboxStyle = 16842860;
        public static final int checked = 16843014;
        public static final int checkedButton = 16843080;
        public static final int checkedTextViewStyle = 16843720;
        public static final int childDivider = 16843025;
        public static final int childIndicator = 16843020;
        public static final int childIndicatorEnd = 16843732;
        public static final int childIndicatorLeft = 16843023;
        public static final int childIndicatorRight = 16843024;
        public static final int childIndicatorStart = 16843731;
        public static final int choiceMode = 16843051;
        public static final int classLoader = 16844139;
        public static final int clearTaskOnLaunch = 16842773;
        public static final int clickable = 16842981;
        public static final int clipChildren = 16842986;
        public static final int clipOrientation = 16843274;
        public static final int clipToPadding = 16842987;
        public static final int closeIcon = 16843905;
        /** @deprecated */
        @Deprecated
        public static final int codes = 16843330;
        public static final int collapseColumns = 16843083;
        public static final int collapseContentDescription = 16843984;
        public static final int collapseIcon = 16844031;
        public static final int color = 16843173;
        public static final int colorAccent = 16843829;
        public static final int colorActivatedHighlight = 16843664;
        public static final int colorBackground = 16842801;
        public static final int colorBackgroundCacheHint = 16843435;
        public static final int colorBackgroundFloating = 16844002;
        public static final int colorButtonNormal = 16843819;
        public static final int colorControlActivated = 16843818;
        public static final int colorControlHighlight = 16843820;
        public static final int colorControlNormal = 16843817;
        public static final int colorEdgeEffect = 16843982;
        public static final int colorError = 16844099;
        public static final int colorFocusedHighlight = 16843663;
        public static final int colorForeground = 16842800;
        public static final int colorForegroundInverse = 16843270;
        public static final int colorLongPressedHighlight = 16843662;
        public static final int colorMode = 16844106;
        public static final int colorMultiSelectHighlight = 16843665;
        public static final int colorPressedHighlight = 16843661;
        public static final int colorPrimary = 16843827;
        public static final int colorPrimaryDark = 16843828;
        public static final int colorSecondary = 16844080;
        public static final int columnCount = 16843639;
        public static final int columnDelay = 16843215;
        public static final int columnOrderPreserved = 16843640;
        public static final int columnWidth = 16843031;
        public static final int commitIcon = 16843909;
        public static final int compatibleWidthLimitDp = 16843621;
        public static final int completionHint = 16843122;
        public static final int completionHintView = 16843123;
        public static final int completionThreshold = 16843124;
        public static final int configChanges = 16842783;
        public static final int configure = 16843357;
        public static final int constantSize = 16843158;
        public static final int content = 16843355;
        public static final int contentAgeHint = 16843961;
        public static final int contentAuthority = 16843408;
        public static final int contentDescription = 16843379;
        public static final int contentInsetEnd = 16843860;
        public static final int contentInsetEndWithActions = 16844067;
        public static final int contentInsetLeft = 16843861;
        public static final int contentInsetRight = 16843862;
        public static final int contentInsetStart = 16843859;
        public static final int contentInsetStartWithNavigation = 16844066;
        public static final int contextClickable = 16844007;
        public static final int contextDescription = 16844078;
        public static final int contextPopupMenuStyle = 16844033;
        public static final int contextUri = 16844077;
        public static final int controlX1 = 16843772;
        public static final int controlX2 = 16843774;
        public static final int controlY1 = 16843773;
        public static final int controlY2 = 16843775;
        public static final int countDown = 16844059;
        public static final int country = 16843962;
        public static final int cropToPadding = 16843043;
        public static final int cursorVisible = 16843090;
        public static final int customNavigationLayout = 16843474;
        public static final int customTokens = 16843579;
        public static final int cycles = 16843220;
        public static final int dashGap = 16843175;
        public static final int dashWidth = 16843174;
        public static final int data = 16842798;
        public static final int datePickerDialogTheme = 16843948;
        public static final int datePickerMode = 16843955;
        public static final int datePickerStyle = 16843612;
        public static final int dateTextAppearance = 16843593;
        /** @deprecated */
        @Deprecated
        public static final int dayOfWeekBackground = 16843924;
        /** @deprecated */
        @Deprecated
        public static final int dayOfWeekTextAppearance = 16843925;
        public static final int debuggable = 16842767;
        public static final int defaultFocusHighlightEnabled = 16844130;
        public static final int defaultHeight = 16844021;
        public static final int defaultToDeviceProtectedStorage = 16844036;
        public static final int defaultValue = 16843245;
        public static final int defaultWidth = 16844020;
        public static final int delay = 16843212;
        public static final int dependency = 16843244;
        public static final int descendantFocusability = 16842993;
        public static final int description = 16842784;
        public static final int detachWallpaper = 16843430;
        public static final int detailColumn = 16843427;
        public static final int detailSocialSummary = 16843428;
        public static final int detailsElementBackground = 16843598;
        public static final int dial = 16843010;
        public static final int dialogCornerRadius = 16844145;
        public static final int dialogIcon = 16843252;
        public static final int dialogLayout = 16843255;
        public static final int dialogMessage = 16843251;
        public static final int dialogPreferenceStyle = 16842897;
        public static final int dialogPreferredPadding = 16843987;
        public static final int dialogTheme = 16843528;
        public static final int dialogTitle = 16843250;
        public static final int digits = 16843110;
        public static final int directBootAware = 16844037;
        public static final int direction = 16843217;
        /** @deprecated */
        @Deprecated
        public static final int directionDescriptions = 16843681;
        public static final int directionPriority = 16843218;
        public static final int disableDependentsState = 16843249;
        public static final int disabledAlpha = 16842803;
        public static final int displayOptions = 16843472;
        public static final int dither = 16843036;
        public static final int divider = 16843049;
        public static final int dividerHeight = 16843050;
        public static final int dividerHorizontal = 16843564;
        public static final int dividerPadding = 16843562;
        public static final int dividerVertical = 16843530;
        public static final int documentLaunchMode = 16843845;
        public static final int drawSelectorOnTop = 16843004;
        public static final int drawable = 16843161;
        public static final int drawableBottom = 16843118;
        public static final int drawableEnd = 16843667;
        public static final int drawableLeft = 16843119;
        public static final int drawablePadding = 16843121;
        public static final int drawableRight = 16843120;
        public static final int drawableStart = 16843666;
        public static final int drawableTint = 16843990;
        public static final int drawableTintMode = 16843991;
        public static final int drawableTop = 16843117;
        public static final int drawingCacheQuality = 16842984;
        public static final int dropDownAnchor = 16843363;
        public static final int dropDownHeight = 16843395;
        public static final int dropDownHintAppearance = 16842888;
        public static final int dropDownHorizontalOffset = 16843436;
        public static final int dropDownItemStyle = 16842886;
        public static final int dropDownListViewStyle = 16842861;
        public static final int dropDownSelector = 16843125;
        public static final int dropDownSpinnerStyle = 16843478;
        public static final int dropDownVerticalOffset = 16843437;
        public static final int dropDownWidth = 16843362;
        public static final int duplicateParentState = 16842985;
        public static final int duration = 16843160;
        public static final int editTextBackground = 16843602;
        public static final int editTextColor = 16843601;
        public static final int editTextPreferenceStyle = 16842898;
        public static final int editTextStyle = 16842862;
        /** @deprecated */
        @Deprecated
        public static final int editable = 16843115;
        public static final int editorExtras = 16843300;
        public static final int elegantTextHeight = 16843869;
        public static final int elevation = 16843840;
        public static final int ellipsize = 16842923;
        public static final int ems = 16843096;
        public static final int enableVrMode = 16844069;
        public static final int enabled = 16842766;
        public static final int end = 16843996;
        public static final int endColor = 16843166;
        public static final int endX = 16844050;
        public static final int endY = 16844051;
        /** @deprecated */
        @Deprecated
        public static final int endYear = 16843133;
        public static final int enforceNavigationBarContrast = 16844293;
        public static final int enforceStatusBarContrast = 16844292;
        public static final int enterFadeDuration = 16843532;
        public static final int entries = 16842930;
        public static final int entryValues = 16843256;
        public static final int eventsInterceptionEnabled = 16843389;
        public static final int excludeClass = 16843842;
        public static final int excludeFromRecents = 16842775;
        public static final int excludeId = 16843841;
        public static final int excludeName = 16843854;
        public static final int exitFadeDuration = 16843533;
        public static final int expandableListPreferredChildIndicatorLeft = 16842834;
        public static final int expandableListPreferredChildIndicatorRight = 16842835;
        public static final int expandableListPreferredChildPaddingLeft = 16842831;
        public static final int expandableListPreferredItemIndicatorLeft = 16842832;
        public static final int expandableListPreferredItemIndicatorRight = 16842833;
        public static final int expandableListPreferredItemPaddingLeft = 16842830;
        public static final int expandableListViewStyle = 16842863;
        public static final int expandableListViewWhiteStyle = 16843446;
        public static final int exported = 16842768;
        public static final int externalService = 16844046;
        public static final int extraTension = 16843371;
        public static final int extractNativeLibs = 16844010;
        public static final int factor = 16843219;
        public static final int fadeDuration = 16843384;
        public static final int fadeEnabled = 16843390;
        public static final int fadeOffset = 16843383;
        public static final int fadeScrollbars = 16843434;
        public static final int fadingEdge = 16842975;
        public static final int fadingEdgeLength = 16842976;
        public static final int fadingMode = 16843745;
        public static final int fallbackLineSpacing = 16844155;
        public static final int fastScrollAlwaysVisible = 16843573;
        public static final int fastScrollEnabled = 16843302;
        public static final int fastScrollOverlayPosition = 16843578;
        public static final int fastScrollPreviewBackgroundLeft = 16843575;
        public static final int fastScrollPreviewBackgroundRight = 16843576;
        public static final int fastScrollStyle = 16843767;
        public static final int fastScrollTextColor = 16843609;
        public static final int fastScrollThumbDrawable = 16843574;
        public static final int fastScrollTrackDrawable = 16843577;
        public static final int fillAfter = 16843197;
        public static final int fillAlpha = 16843980;
        public static final int fillBefore = 16843196;
        public static final int fillColor = 16843780;
        public static final int fillEnabled = 16843343;
        public static final int fillType = 16844062;
        public static final int fillViewport = 16843130;
        public static final int filter = 16843035;
        public static final int filterTouchesWhenObscured = 16843460;
        public static final int fingerprintAuthDrawable = 16844008;
        public static final int finishOnCloseSystemDialogs = 16843431;
        public static final int finishOnTaskLaunch = 16842772;
        public static final int firstBaselineToTopHeight = 16844157;
        public static final int firstDayOfWeek = 16843581;
        public static final int fitsSystemWindows = 16842973;
        public static final int flipInterval = 16843129;
        public static final int focusable = 16842970;
        public static final int focusableInTouchMode = 16842971;
        public static final int focusedByDefault = 16844100;
        /** @deprecated */
        @Deprecated
        public static final int focusedMonthDateColor = 16843587;
        public static final int font = 16844082;
        public static final int fontFamily = 16843692;
        public static final int fontFeatureSettings = 16843959;
        public static final int fontProviderAuthority = 16844112;
        public static final int fontProviderCerts = 16844125;
        public static final int fontProviderPackage = 16844119;
        public static final int fontProviderQuery = 16844113;
        public static final int fontStyle = 16844095;
        public static final int fontVariationSettings = 16844144;
        public static final int fontWeight = 16844083;
        public static final int footerDividersEnabled = 16843311;
        public static final int forceDarkAllowed = 16844172;
        public static final int forceHasOverlappingRendering = 16844065;
        public static final int forceUriPermissions = 16844191;
        public static final int foreground = 16843017;
        public static final int foregroundGravity = 16843264;
        public static final int foregroundServiceType = 16844185;
        public static final int foregroundTint = 16843885;
        public static final int foregroundTintMode = 16843886;
        public static final int format = 16843013;
        public static final int format12Hour = 16843722;
        public static final int format24Hour = 16843723;
        public static final int fraction = 16843992;
        public static final int fragment = 16843491;
        public static final int fragmentAllowEnterTransitionOverlap = 16843976;
        public static final int fragmentAllowReturnTransitionOverlap = 16843977;
        public static final int fragmentCloseEnterAnimation = 16843495;
        public static final int fragmentCloseExitAnimation = 16843496;
        public static final int fragmentEnterTransition = 16843971;
        public static final int fragmentExitTransition = 16843970;
        public static final int fragmentFadeEnterAnimation = 16843497;
        public static final int fragmentFadeExitAnimation = 16843498;
        public static final int fragmentOpenEnterAnimation = 16843493;
        public static final int fragmentOpenExitAnimation = 16843494;
        public static final int fragmentReenterTransition = 16843975;
        public static final int fragmentReturnTransition = 16843973;
        public static final int fragmentSharedElementEnterTransition = 16843972;
        public static final int fragmentSharedElementReturnTransition = 16843974;
        public static final int freezesText = 16843116;
        public static final int fromAlpha = 16843210;
        public static final int fromDegrees = 16843187;
        public static final int fromId = 16843850;
        public static final int fromScene = 16843741;
        public static final int fromXDelta = 16843206;
        public static final int fromXScale = 16843202;
        public static final int fromYDelta = 16843208;
        public static final int fromYScale = 16843204;
        public static final int fullBackupContent = 16844011;
        public static final int fullBackupOnly = 16843891;
        public static final int fullBright = 16842954;
        public static final int fullDark = 16842950;
        public static final int functionalTest = 16842787;
        public static final int galleryItemBackground = 16842828;
        public static final int galleryStyle = 16842864;
        public static final int gestureColor = 16843381;
        public static final int gestureStrokeAngleThreshold = 16843388;
        public static final int gestureStrokeLengthThreshold = 16843386;
        public static final int gestureStrokeSquarenessThreshold = 16843387;
        public static final int gestureStrokeType = 16843385;
        public static final int gestureStrokeWidth = 16843380;
        public static final int glEsVersion = 16843393;
        public static final int goIcon = 16843906;
        public static final int gradientRadius = 16843172;
        public static final int grantUriPermissions = 16842779;
        public static final int gravity = 16842927;
        public static final int gridViewStyle = 16842865;
        public static final int groupIndicator = 16843019;
        public static final int hand_hour = 16843011;
        public static final int hand_minute = 16843012;
        public static final int handle = 16843354;
        public static final int handleProfiling = 16842786;
        public static final int hapticFeedbackEnabled = 16843358;
        public static final int hardwareAccelerated = 16843475;
        public static final int hasCode = 16842764;
        public static final int hasFragileUserData = 16844186;
        /** @deprecated */
        @Deprecated
        public static final int headerAmPmTextAppearance = 16843936;
        public static final int headerBackground = 16843055;
        /** @deprecated */
        @Deprecated
        public static final int headerDayOfMonthTextAppearance = 16843927;
        public static final int headerDividersEnabled = 16843310;
        /** @deprecated */
        @Deprecated
        public static final int headerMonthTextAppearance = 16843926;
        /** @deprecated */
        @Deprecated
        public static final int headerTimeTextAppearance = 16843935;
        /** @deprecated */
        @Deprecated
        public static final int headerYearTextAppearance = 16843928;
        public static final int height = 16843093;
        public static final int hideOnContentScroll = 16843843;
        public static final int hint = 16843088;
        public static final int homeAsUpIndicator = 16843531;
        public static final int homeLayout = 16843549;
        public static final int horizontalDivider = 16843053;
        /** @deprecated */
        @Deprecated
        public static final int horizontalGap = 16843327;
        public static final int horizontalScrollViewStyle = 16843603;
        public static final int horizontalSpacing = 16843028;
        public static final int host = 16842792;
        public static final int hotSpotX = 16844055;
        public static final int hotSpotY = 16844056;
        public static final int hyphenationFrequency = 16843998;
        public static final int icon = 16842754;
        /** @deprecated */
        @Deprecated
        public static final int iconPreview = 16843337;
        public static final int iconSpaceReserved = 16844129;
        public static final int iconTint = 16844126;
        public static final int iconTintMode = 16844127;
        public static final int iconifiedByDefault = 16843514;
        public static final int id = 16842960;
        public static final int identifier = 16844294;
        public static final int ignoreGravity = 16843263;
        public static final int imageButtonStyle = 16842866;
        public static final int imageWellStyle = 16842867;
        public static final int imeActionId = 16843366;
        public static final int imeActionLabel = 16843365;
        public static final int imeExtractEnterAnimation = 16843368;
        public static final int imeExtractExitAnimation = 16843369;
        public static final int imeFullscreenBackground = 16843308;
        public static final int imeOptions = 16843364;
        public static final int imeSubtypeExtraValue = 16843502;
        public static final int imeSubtypeLocale = 16843500;
        public static final int imeSubtypeMode = 16843501;
        public static final int immersive = 16843456;
        public static final int importantForAccessibility = 16843690;
        public static final int importantForAutofill = 16844120;
        public static final int inAnimation = 16843127;
        public static final int includeFontPadding = 16843103;
        public static final int includeInGlobalSearch = 16843374;
        public static final int indeterminate = 16843065;
        public static final int indeterminateBehavior = 16843070;
        public static final int indeterminateDrawable = 16843067;
        public static final int indeterminateDuration = 16843069;
        public static final int indeterminateOnly = 16843066;
        public static final int indeterminateProgressStyle = 16843544;
        public static final int indeterminateTint = 16843881;
        public static final int indeterminateTintMode = 16843882;
        public static final int indicatorEnd = 16843730;
        public static final int indicatorLeft = 16843021;
        public static final int indicatorRight = 16843022;
        public static final int indicatorStart = 16843729;
        public static final int inflatedId = 16842995;
        public static final int inheritShowWhenLocked = 16844188;
        public static final int initOrder = 16842778;
        public static final int initialKeyguardLayout = 16843714;
        public static final int initialLayout = 16843345;
        public static final int innerRadius = 16843359;
        public static final int innerRadiusRatio = 16843163;
        /** @deprecated */
        @Deprecated
        public static final int inputMethod = 16843112;
        public static final int inputType = 16843296;
        public static final int inset = 16843957;
        public static final int insetBottom = 16843194;
        public static final int insetLeft = 16843191;
        public static final int insetRight = 16843192;
        public static final int insetTop = 16843193;
        public static final int installLocation = 16843447;
        public static final int interactiveUiTimeout = 16844181;
        public static final int interpolator = 16843073;
        public static final int isAlwaysSyncable = 16843571;
        public static final int isAsciiCapable = 16843753;
        public static final int isAuxiliary = 16843647;
        public static final int isDefault = 16843297;
        public static final int isFeatureSplit = 16844123;
        public static final int isGame = 16843764;
        public static final int isIndicator = 16843079;
        public static final int isLightTheme = 16844176;
        /** @deprecated */
        @Deprecated
        public static final int isModifier = 16843334;
        /** @deprecated */
        @Deprecated
        public static final int isRepeatable = 16843336;
        public static final int isScrollContainer = 16843342;
        public static final int isSplitRequired = 16844177;
        public static final int isStatic = 16844122;
        /** @deprecated */
        @Deprecated
        public static final int isSticky = 16843335;
        public static final int isolatedProcess = 16843689;
        public static final int isolatedSplits = 16844107;
        public static final int itemBackground = 16843056;
        public static final int itemIconDisabledAlpha = 16843057;
        public static final int itemPadding = 16843565;
        public static final int itemTextAppearance = 16843052;
        public static final int justificationMode = 16844135;
        public static final int keepScreenOn = 16843286;
        public static final int key = 16843240;
        /** @deprecated */
        @Deprecated
        public static final int keyBackground = 16843315;
        /** @deprecated */
        @Deprecated
        public static final int keyEdgeFlags = 16843333;
        /** @deprecated */
        @Deprecated
        public static final int keyHeight = 16843326;
        /** @deprecated */
        @Deprecated
        public static final int keyIcon = 16843340;
        /** @deprecated */
        @Deprecated
        public static final int keyLabel = 16843339;
        /** @deprecated */
        @Deprecated
        public static final int keyOutputText = 16843338;
        /** @deprecated */
        @Deprecated
        public static final int keyPreviewHeight = 16843321;
        /** @deprecated */
        @Deprecated
        public static final int keyPreviewLayout = 16843319;
        /** @deprecated */
        @Deprecated
        public static final int keyPreviewOffset = 16843320;
        public static final int keySet = 16843739;
        /** @deprecated */
        @Deprecated
        public static final int keyTextColor = 16843318;
        /** @deprecated */
        @Deprecated
        public static final int keyTextSize = 16843316;
        /** @deprecated */
        @Deprecated
        public static final int keyWidth = 16843325;
        public static final int keyboardLayout = 16843691;
        /** @deprecated */
        @Deprecated
        public static final int keyboardMode = 16843341;
        public static final int keyboardNavigationCluster = 16844096;
        public static final int keycode = 16842949;
        public static final int killAfterRestore = 16843420;
        public static final int label = 16842753;
        public static final int labelFor = 16843718;
        /** @deprecated */
        @Deprecated
        public static final int labelTextSize = 16843317;
        public static final int languageTag = 16844040;
        public static final int largeHeap = 16843610;
        public static final int largeScreens = 16843398;
        public static final int largestWidthLimitDp = 16843622;
        public static final int lastBaselineToBottomHeight = 16844158;
        public static final int launchMode = 16842781;
        public static final int launchTaskBehindSourceAnimation = 16843922;
        public static final int launchTaskBehindTargetAnimation = 16843921;
        public static final int layerType = 16843604;
        public static final int layout = 16842994;
        public static final int layoutAnimation = 16842988;
        public static final int layoutDirection = 16843698;
        public static final int layoutMode = 16843738;
        public static final int layout_above = 16843140;
        public static final int layout_alignBaseline = 16843142;
        public static final int layout_alignBottom = 16843146;
        public static final int layout_alignEnd = 16843706;
        public static final int layout_alignLeft = 16843143;
        public static final int layout_alignParentBottom = 16843150;
        public static final int layout_alignParentEnd = 16843708;
        public static final int layout_alignParentLeft = 16843147;
        public static final int layout_alignParentRight = 16843149;
        public static final int layout_alignParentStart = 16843707;
        public static final int layout_alignParentTop = 16843148;
        public static final int layout_alignRight = 16843145;
        public static final int layout_alignStart = 16843705;
        public static final int layout_alignTop = 16843144;
        public static final int layout_alignWithParentIfMissing = 16843154;
        public static final int layout_below = 16843141;
        public static final int layout_centerHorizontal = 16843152;
        public static final int layout_centerInParent = 16843151;
        public static final int layout_centerVertical = 16843153;
        public static final int layout_column = 16843084;
        public static final int layout_columnSpan = 16843645;
        public static final int layout_columnWeight = 16843865;
        public static final int layout_gravity = 16842931;
        public static final int layout_height = 16842997;
        public static final int layout_margin = 16842998;
        public static final int layout_marginBottom = 16843002;
        public static final int layout_marginEnd = 16843702;
        public static final int layout_marginHorizontal = 16844091;
        public static final int layout_marginLeft = 16842999;
        public static final int layout_marginRight = 16843001;
        public static final int layout_marginStart = 16843701;
        public static final int layout_marginTop = 16843000;
        public static final int layout_marginVertical = 16844092;
        public static final int layout_row = 16843643;
        public static final int layout_rowSpan = 16843644;
        public static final int layout_rowWeight = 16843864;
        public static final int layout_scale = 16843155;
        public static final int layout_span = 16843085;
        public static final int layout_toEndOf = 16843704;
        public static final int layout_toLeftOf = 16843138;
        public static final int layout_toRightOf = 16843139;
        public static final int layout_toStartOf = 16843703;
        public static final int layout_weight = 16843137;
        public static final int layout_width = 16842996;
        public static final int layout_x = 16843135;
        public static final int layout_y = 16843136;
        public static final int left = 16843181;
        public static final int letterSpacing = 16843958;
        public static final int level = 16844032;
        public static final int lineHeight = 16844159;
        public static final int lineSpacingExtra = 16843287;
        public static final int lineSpacingMultiplier = 16843288;
        public static final int lines = 16843092;
        public static final int linksClickable = 16842929;
        public static final int listChoiceBackgroundIndicator = 16843504;
        public static final int listChoiceIndicatorMultiple = 16843290;
        public static final int listChoiceIndicatorSingle = 16843289;
        public static final int listDivider = 16843284;
        public static final int listDividerAlertDialog = 16843525;
        public static final int listMenuViewStyle = 16844018;
        public static final int listPopupWindowStyle = 16843519;
        public static final int listPreferredItemHeight = 16842829;
        public static final int listPreferredItemHeightLarge = 16843654;
        public static final int listPreferredItemHeightSmall = 16843655;
        public static final int listPreferredItemPaddingEnd = 16843710;
        public static final int listPreferredItemPaddingLeft = 16843683;
        public static final int listPreferredItemPaddingRight = 16843684;
        public static final int listPreferredItemPaddingStart = 16843709;
        public static final int listSelector = 16843003;
        public static final int listSeparatorTextViewStyle = 16843272;
        public static final int listViewStyle = 16842868;
        public static final int listViewWhiteStyle = 16842869;
        public static final int lockTaskMode = 16844013;
        public static final int logo = 16843454;
        public static final int logoDescription = 16844009;
        public static final int longClickable = 16842982;
        public static final int loopViews = 16843527;
        public static final int manageSpaceActivity = 16842756;
        public static final int mapViewStyle = 16842890;
        public static final int marqueeRepeatLimit = 16843293;
        public static final int matchOrder = 16843855;
        public static final int max = 16843062;
        public static final int maxAspectRatio = 16844128;
        public static final int maxButtonHeight = 16844029;
        public static final int maxDate = 16843584;
        public static final int maxEms = 16843095;
        public static final int maxHeight = 16843040;
        public static final int maxItemsPerRow = 16843060;
        public static final int maxLength = 16843104;
        public static final int maxLevel = 16843186;
        public static final int maxLines = 16843091;
        public static final int maxLongVersionCode = 16844163;
        public static final int maxRecents = 16843846;
        public static final int maxRows = 16843059;
        public static final int maxSdkVersion = 16843377;
        public static final int maxWidth = 16843039;
        public static final int maximumAngle = 16843903;
        public static final int measureAllChildren = 16843018;
        public static final int measureWithLargestChild = 16843476;
        public static final int mediaRouteButtonStyle = 16843693;
        public static final int mediaRouteTypes = 16843694;
        public static final int menuCategory = 16843230;
        public static final int mimeType = 16842790;
        public static final int min = 16844089;
        public static final int minAspectRatio = 16844187;
        public static final int minDate = 16843583;
        public static final int minEms = 16843098;
        public static final int minHeight = 16843072;
        public static final int minLevel = 16843185;
        public static final int minLines = 16843094;
        public static final int minResizeHeight = 16843670;
        public static final int minResizeWidth = 16843669;
        public static final int minSdkVersion = 16843276;
        public static final int minWidth = 16843071;
        public static final int minimumHorizontalAngle = 16843901;
        public static final int minimumVerticalAngle = 16843902;
        public static final int mipMap = 16843725;
        public static final int mirrorForRtl = 16843726;
        public static final int mode = 16843134;
        public static final int moreIcon = 16843061;
        public static final int multiArch = 16843918;
        public static final int multiprocess = 16842771;
        public static final int name = 16842755;
        public static final int navigationBarColor = 16843858;
        public static final int navigationBarDividerColor = 16844141;
        public static final int navigationContentDescription = 16843969;
        public static final int navigationIcon = 16843968;
        public static final int navigationMode = 16843471;
        public static final int negativeButtonText = 16843254;
        public static final int nestedScrollingEnabled = 16843830;
        public static final int networkSecurityConfig = 16844071;
        public static final int nextClusterForward = 16844098;
        public static final int nextFocusDown = 16842980;
        public static final int nextFocusForward = 16843580;
        public static final int nextFocusLeft = 16842977;
        public static final int nextFocusRight = 16842978;
        public static final int nextFocusUp = 16842979;
        public static final int noHistory = 16843309;
        public static final int nonInteractiveUiTimeout = 16844175;
        public static final int normalScreens = 16843397;
        public static final int notificationTimeout = 16843651;
        public static final int numColumns = 16843032;
        public static final int numStars = 16843076;
        public static final int numberPickerStyle = 16844068;
        public static final int numbersBackgroundColor = 16843938;
        public static final int numbersInnerTextColor = 16844001;
        public static final int numbersSelectorColor = 16843939;
        public static final int numbersTextColor = 16843937;
        /** @deprecated */
        @Deprecated
        public static final int numeric = 16843109;
        public static final int numericModifiers = 16844111;
        public static final int numericShortcut = 16843236;
        public static final int offset = 16844052;
        public static final int onClick = 16843375;
        public static final int oneshot = 16843159;
        public static final int opacity = 16843550;
        public static final int opticalInsetBottom = 16844171;
        public static final int opticalInsetLeft = 16844168;
        public static final int opticalInsetRight = 16844170;
        public static final int opticalInsetTop = 16844169;
        public static final int order = 16843242;
        public static final int orderInCategory = 16843231;
        public static final int ordering = 16843490;
        public static final int orderingFromXml = 16843239;
        public static final int orientation = 16842948;
        public static final int outAnimation = 16843128;
        public static final int outlineAmbientShadowColor = 16844162;
        public static final int outlineProvider = 16843960;
        public static final int outlineSpotShadowColor = 16844161;
        public static final int overScrollFooter = 16843459;
        public static final int overScrollHeader = 16843458;
        public static final int overScrollMode = 16843457;
        public static final int overlapAnchor = 16843874;
        public static final int overridesImplicitlyEnabledSubtype = 16843682;
        public static final int packageNames = 16843649;
        public static final int packageType = 16844167;
        public static final int padding = 16842965;
        public static final int paddingBottom = 16842969;
        public static final int paddingEnd = 16843700;
        public static final int paddingHorizontal = 16844093;
        public static final int paddingLeft = 16842966;
        public static final int paddingMode = 16843863;
        public static final int paddingRight = 16842968;
        public static final int paddingStart = 16843699;
        public static final int paddingTop = 16842967;
        public static final int paddingVertical = 16844094;
        public static final int panelBackground = 16842846;
        public static final int panelColorBackground = 16842849;
        public static final int panelColorForeground = 16842848;
        public static final int panelFullBackground = 16842847;
        public static final int panelTextAppearance = 16842850;
        public static final int parentActivityName = 16843687;
        /** @deprecated */
        @Deprecated
        public static final int password = 16843100;
        public static final int path = 16842794;
        public static final int pathData = 16843781;
        public static final int pathPattern = 16842796;
        public static final int pathPrefix = 16842795;
        public static final int patternPathData = 16843978;
        public static final int permission = 16842758;
        public static final int permissionFlags = 16843719;
        public static final int permissionGroup = 16842762;
        public static final int permissionGroupFlags = 16843717;
        public static final int persistableMode = 16843821;
        public static final int persistent = 16842765;
        public static final int persistentDrawingCache = 16842990;
        public static final int persistentWhenFeatureAvailable = 16844131;
        /** @deprecated */
        @Deprecated
        public static final int phoneNumber = 16843111;
        public static final int pivotX = 16843189;
        public static final int pivotY = 16843190;
        public static final int pointerIcon = 16844041;
        public static final int popupAnimationStyle = 16843465;
        public static final int popupBackground = 16843126;
        /** @deprecated */
        @Deprecated
        public static final int popupCharacters = 16843332;
        public static final int popupElevation = 16843916;
        public static final int popupEnterTransition = 16844063;
        public static final int popupExitTransition = 16844064;
        /** @deprecated */
        @Deprecated
        public static final int popupKeyboard = 16843331;
        /** @deprecated */
        @Deprecated
        public static final int popupLayout = 16843323;
        public static final int popupMenuStyle = 16843520;
        public static final int popupTheme = 16843945;
        public static final int popupWindowStyle = 16842870;
        public static final int port = 16842793;
        public static final int positiveButtonText = 16843253;
        public static final int preferenceCategoryStyle = 16842892;
        public static final int preferenceFragmentStyle = 16844038;
        public static final int preferenceInformationStyle = 16842893;
        public static final int preferenceLayoutChild = 16842900;
        public static final int preferenceScreenStyle = 16842891;
        public static final int preferenceStyle = 16842894;
        public static final int presentationTheme = 16843712;
        public static final int previewImage = 16843482;
        public static final int primaryContentAlpha = 16844114;
        public static final int priority = 16842780;
        public static final int privateImeOptions = 16843299;
        public static final int process = 16842769;
        public static final int progress = 16843063;
        public static final int progressBackgroundTint = 16843877;
        public static final int progressBackgroundTintMode = 16843878;
        public static final int progressBarPadding = 16843545;
        public static final int progressBarStyle = 16842871;
        public static final int progressBarStyleHorizontal = 16842872;
        public static final int progressBarStyleInverse = 16843399;
        public static final int progressBarStyleLarge = 16842874;
        public static final int progressBarStyleLargeInverse = 16843401;
        public static final int progressBarStyleSmall = 16842873;
        public static final int progressBarStyleSmallInverse = 16843400;
        public static final int progressBarStyleSmallTitle = 16843279;
        public static final int progressDrawable = 16843068;
        public static final int progressTint = 16843875;
        public static final int progressTintMode = 16843876;
        public static final int prompt = 16843131;
        public static final int propertyName = 16843489;
        public static final int propertyXName = 16843892;
        public static final int propertyYName = 16843893;
        public static final int protectionLevel = 16842761;
        public static final int publicKey = 16843686;
        public static final int queryActionMsg = 16843227;
        public static final int queryAfterZeroResults = 16843394;
        public static final int queryBackground = 16843911;
        public static final int queryHint = 16843608;
        public static final int quickContactBadgeStyleSmallWindowLarge = 16843443;
        public static final int quickContactBadgeStyleSmallWindowMedium = 16843442;
        public static final int quickContactBadgeStyleSmallWindowSmall = 16843441;
        public static final int quickContactBadgeStyleWindowLarge = 16843440;
        public static final int quickContactBadgeStyleWindowMedium = 16843439;
        public static final int quickContactBadgeStyleWindowSmall = 16843438;
        public static final int radioButtonStyle = 16842878;
        public static final int radius = 16843176;
        public static final int rating = 16843077;
        public static final int ratingBarStyle = 16842876;
        public static final int ratingBarStyleIndicator = 16843280;
        public static final int ratingBarStyleSmall = 16842877;
        public static final int readPermission = 16842759;
        public static final int recognitionService = 16843932;
        public static final int recreateOnConfigChanges = 16844103;
        public static final int recycleEnabled = 16844121;
        public static final int relinquishTaskIdentity = 16843894;
        public static final int reparent = 16843964;
        public static final int reparentWithOverlay = 16843965;
        public static final int repeatCount = 16843199;
        public static final int repeatMode = 16843200;
        public static final int reqFiveWayNav = 16843314;
        public static final int reqHardKeyboard = 16843305;
        public static final int reqKeyboardType = 16843304;
        public static final int reqNavigation = 16843306;
        public static final int reqTouchScreen = 16843303;
        public static final int requestLegacyExternalStorage = 16844291;
        public static final int requireDeviceUnlock = 16843756;
        public static final int required = 16843406;
        public static final int requiredAccountType = 16843734;
        public static final int requiredFeature = 16844116;
        public static final int requiredForAllUsers = 16843728;
        public static final int requiredNotFeature = 16844117;
        public static final int requiresFadingEdge = 16843685;
        public static final int requiresSmallestWidthDp = 16843620;
        public static final int resizeClip = 16843983;
        public static final int resizeMode = 16843619;
        public static final int resizeable = 16843405;
        public static final int resizeableActivity = 16844022;
        public static final int resource = 16842789;
        public static final int restoreAnyVersion = 16843450;
        /** @deprecated */
        @Deprecated
        public static final int restoreNeedsApplication = 16843421;
        public static final int restrictedAccountType = 16843733;
        public static final int restrictionType = 16843923;
        public static final int resumeWhilePausing = 16843954;
        public static final int reversible = 16843851;
        public static final int revisionCode = 16843989;
        public static final int right = 16843183;
        public static final int ringtonePreferenceStyle = 16842899;
        public static final int ringtoneType = 16843257;
        public static final int rotation = 16843558;
        public static final int rotationAnimation = 16844090;
        public static final int rotationX = 16843559;
        public static final int rotationY = 16843560;
        public static final int roundIcon = 16844076;
        public static final int rowCount = 16843637;
        public static final int rowDelay = 16843216;
        /** @deprecated */
        @Deprecated
        public static final int rowEdgeFlags = 16843329;
        public static final int rowHeight = 16843058;
        public static final int rowOrderPreserved = 16843638;
        public static final int saveEnabled = 16842983;
        public static final int scaleGravity = 16843262;
        public static final int scaleHeight = 16843261;
        public static final int scaleType = 16843037;
        public static final int scaleWidth = 16843260;
        public static final int scaleX = 16843556;
        public static final int scaleY = 16843557;
        public static final int scheme = 16842791;
        public static final int screenDensity = 16843467;
        public static final int screenOrientation = 16842782;
        public static final int screenReaderFocusable = 16844148;
        public static final int screenSize = 16843466;
        public static final int scrollHorizontally = 16843099;
        public static final int scrollIndicators = 16844006;
        public static final int scrollViewStyle = 16842880;
        public static final int scrollX = 16842962;
        public static final int scrollY = 16842963;
        public static final int scrollbarAlwaysDrawHorizontalTrack = 16842856;
        public static final int scrollbarAlwaysDrawVerticalTrack = 16842857;
        public static final int scrollbarDefaultDelayBeforeFade = 16843433;
        public static final int scrollbarFadeDuration = 16843432;
        public static final int scrollbarSize = 16842851;
        public static final int scrollbarStyle = 16842879;
        public static final int scrollbarThumbHorizontal = 16842852;
        public static final int scrollbarThumbVertical = 16842853;
        public static final int scrollbarTrackHorizontal = 16842854;
        public static final int scrollbarTrackVertical = 16842855;
        public static final int scrollbars = 16842974;
        public static final int scrollingCache = 16843006;
        /** @deprecated */
        @Deprecated
        public static final int searchButtonText = 16843269;
        public static final int searchHintIcon = 16843988;
        public static final int searchIcon = 16843907;
        public static final int searchMode = 16843221;
        public static final int searchSettingsDescription = 16843402;
        public static final int searchSuggestAuthority = 16843222;
        public static final int searchSuggestIntentAction = 16843225;
        public static final int searchSuggestIntentData = 16843226;
        public static final int searchSuggestPath = 16843223;
        public static final int searchSuggestSelection = 16843224;
        public static final int searchSuggestThreshold = 16843373;
        public static final int searchViewStyle = 16843904;
        public static final int secondaryContentAlpha = 16844115;
        public static final int secondaryProgress = 16843064;
        public static final int secondaryProgressTint = 16843879;
        public static final int secondaryProgressTintMode = 16843880;
        public static final int secureElementName = 16844290;
        public static final int seekBarStyle = 16842875;
        public static final int segmentedButtonStyle = 16843568;
        public static final int selectAllOnFocus = 16843102;
        public static final int selectable = 16843238;
        public static final int selectableItemBackground = 16843534;
        public static final int selectableItemBackgroundBorderless = 16843868;
        /** @deprecated */
        @Deprecated
        public static final int selectedDateVerticalBar = 16843591;
        /** @deprecated */
        @Deprecated
        public static final int selectedWeekBackgroundColor = 16843586;
        public static final int selectionDividerHeight = 16844184;
        public static final int sessionService = 16843837;
        public static final int settingsActivity = 16843301;
        public static final int settingsSliceUri = 16844179;
        public static final int setupActivity = 16843766;
        public static final int shadowColor = 16843105;
        public static final int shadowDx = 16843106;
        public static final int shadowDy = 16843107;
        public static final int shadowRadius = 16843108;
        public static final int shape = 16843162;
        public static final int shareInterpolator = 16843195;
        /** @deprecated */
        @Deprecated
        public static final int sharedUserId = 16842763;
        /** @deprecated */
        @Deprecated
        public static final int sharedUserLabel = 16843361;
        public static final int shell = 16844180;
        public static final int shortcutDisabledMessage = 16844075;
        public static final int shortcutId = 16844072;
        public static final int shortcutLongLabel = 16844074;
        public static final int shortcutShortLabel = 16844073;
        public static final int shouldDisableView = 16843246;
        public static final int showAsAction = 16843481;
        public static final int showDefault = 16843258;
        public static final int showDividers = 16843561;
        public static final int showForAllUsers = 16844015;
        public static final int showMetadataInPreview = 16844079;
        /** @deprecated */
        @Deprecated
        public static final int showOnLockScreen = 16843721;
        public static final int showSilent = 16843259;
        public static final int showText = 16843949;
        /** @deprecated */
        @Deprecated
        public static final int showWeekNumber = 16843582;
        public static final int showWhenLocked = 16844137;
        /** @deprecated */
        @Deprecated
        public static final int shownWeekCount = 16843585;
        public static final int shrinkColumns = 16843082;
        /** @deprecated */
        @Deprecated
        public static final int singleLine = 16843101;
        public static final int singleLineTitle = 16844124;
        public static final int singleUser = 16843711;
        public static final int slideEdge = 16843824;
        public static final int smallIcon = 16843422;
        public static final int smallScreens = 16843396;
        public static final int smoothScrollbar = 16843313;
        public static final int soundEffectsEnabled = 16843285;
        public static final int spacing = 16843027;
        public static final int spinnerDropDownItemStyle = 16842887;
        public static final int spinnerItemStyle = 16842889;
        public static final int spinnerMode = 16843505;
        public static final int spinnerStyle = 16842881;
        public static final int spinnersShown = 16843595;
        public static final int splitMotionEvents = 16843503;
        public static final int splitName = 16844105;
        public static final int splitTrack = 16843852;
        public static final int spotShadowAlpha = 16843967;
        public static final int src = 16843033;
        public static final int ssp = 16843747;
        public static final int sspPattern = 16843749;
        public static final int sspPrefix = 16843748;
        public static final int stackFromBottom = 16843005;
        public static final int stackViewStyle = 16843838;
        public static final int starStyle = 16842882;
        public static final int start = 16843995;
        public static final int startColor = 16843165;
        public static final int startDelay = 16843746;
        public static final int startOffset = 16843198;
        public static final int startX = 16844048;
        public static final int startY = 16844049;
        /** @deprecated */
        @Deprecated
        public static final int startYear = 16843132;
        public static final int stateListAnimator = 16843848;
        public static final int stateNotNeeded = 16842774;
        public static final int state_above_anchor = 16842922;
        public static final int state_accelerated = 16843547;
        public static final int state_activated = 16843518;
        public static final int state_active = 16842914;
        public static final int state_checkable = 16842911;
        public static final int state_checked = 16842912;
        public static final int state_drag_can_accept = 16843624;
        public static final int state_drag_hovered = 16843625;
        public static final int state_empty = 16842921;
        public static final int state_enabled = 16842910;
        public static final int state_expanded = 16842920;
        public static final int state_first = 16842916;
        public static final int state_focused = 16842908;
        public static final int state_hovered = 16843623;
        public static final int state_last = 16842918;
        /** @deprecated */
        @Deprecated
        public static final int state_long_pressable = 16843324;
        public static final int state_middle = 16842917;
        public static final int state_multiline = 16843597;
        public static final int state_pressed = 16842919;
        public static final int state_selected = 16842913;
        public static final int state_single = 16842915;
        public static final int state_window_focused = 16842909;
        public static final int staticWallpaperPreview = 16843569;
        public static final int statusBarColor = 16843857;
        public static final int stepSize = 16843078;
        public static final int stopWithTask = 16843626;
        public static final int streamType = 16843273;
        public static final int stretchColumns = 16843081;
        public static final int stretchMode = 16843030;
        public static final int strokeAlpha = 16843979;
        public static final int strokeColor = 16843782;
        public static final int strokeLineCap = 16843787;
        public static final int strokeLineJoin = 16843788;
        public static final int strokeMiterLimit = 16843789;
        public static final int strokeWidth = 16843783;
        public static final int subMenuArrow = 16844019;
        public static final int submitBackground = 16843912;
        public static final int subtitle = 16843473;
        public static final int subtitleTextAppearance = 16843823;
        public static final int subtitleTextColor = 16844004;
        public static final int subtitleTextStyle = 16843513;
        public static final int subtypeExtraValue = 16843674;
        public static final int subtypeId = 16843713;
        public static final int subtypeLocale = 16843673;
        public static final int suggestActionMsg = 16843228;
        public static final int suggestActionMsgColumn = 16843229;
        public static final int suggestionRowLayout = 16843910;
        public static final int summary = 16843241;
        public static final int summaryColumn = 16843426;
        public static final int summaryOff = 16843248;
        public static final int summaryOn = 16843247;
        public static final int supportsAssist = 16844016;
        public static final int supportsLaunchVoiceAssistFromKeyguard = 16844017;
        public static final int supportsLocalInteraction = 16844047;
        public static final int supportsMultipleDisplays = 16844182;
        public static final int supportsPictureInPicture = 16844023;
        public static final int supportsRtl = 16843695;
        public static final int supportsSwitchingToNextInputMethod = 16843755;
        public static final int supportsUploading = 16843419;
        public static final int switchMinWidth = 16843632;
        public static final int switchPadding = 16843633;
        public static final int switchPreferenceStyle = 16843629;
        public static final int switchStyle = 16843839;
        public static final int switchTextAppearance = 16843630;
        public static final int switchTextOff = 16843628;
        public static final int switchTextOn = 16843627;
        public static final int syncable = 16842777;
        public static final int tabStripEnabled = 16843453;
        public static final int tabStripLeft = 16843451;
        public static final int tabStripRight = 16843452;
        public static final int tabWidgetStyle = 16842883;
        public static final int tag = 16842961;
        public static final int targetActivity = 16843266;
        public static final int targetClass = 16842799;
        /** @deprecated */
        @Deprecated
        public static final int targetDescriptions = 16843680;
        public static final int targetId = 16843740;
        public static final int targetName = 16843853;
        public static final int targetPackage = 16842785;
        public static final int targetProcesses = 16844097;
        /** @deprecated */
        @Deprecated
        public static final int targetSandboxVersion = 16844108;
        public static final int targetSdkVersion = 16843376;
        public static final int taskAffinity = 16842770;
        public static final int taskCloseEnterAnimation = 16842942;
        public static final int taskCloseExitAnimation = 16842943;
        public static final int taskOpenEnterAnimation = 16842940;
        public static final int taskOpenExitAnimation = 16842941;
        public static final int taskToBackEnterAnimation = 16842946;
        public static final int taskToBackExitAnimation = 16842947;
        public static final int taskToFrontEnterAnimation = 16842944;
        public static final int taskToFrontExitAnimation = 16842945;
        public static final int tension = 16843370;
        public static final int testOnly = 16843378;
        public static final int text = 16843087;
        public static final int textAlignment = 16843697;
        public static final int textAllCaps = 16843660;
        public static final int textAppearance = 16842804;
        public static final int textAppearanceButton = 16843271;
        public static final int textAppearanceInverse = 16842805;
        public static final int textAppearanceLarge = 16842816;
        public static final int textAppearanceLargeInverse = 16842819;
        public static final int textAppearanceLargePopupMenu = 16843521;
        public static final int textAppearanceListItem = 16843678;
        public static final int textAppearanceListItemSecondary = 16843826;
        public static final int textAppearanceListItemSmall = 16843679;
        public static final int textAppearanceMedium = 16842817;
        public static final int textAppearanceMediumInverse = 16842820;
        public static final int textAppearancePopupMenuHeader = 16844034;
        public static final int textAppearanceSearchResultSubtitle = 16843424;
        public static final int textAppearanceSearchResultTitle = 16843425;
        public static final int textAppearanceSmall = 16842818;
        public static final int textAppearanceSmallInverse = 16842821;
        public static final int textAppearanceSmallPopupMenu = 16843522;
        public static final int textCheckMark = 16842822;
        public static final int textCheckMarkInverse = 16842823;
        public static final int textColor = 16842904;
        public static final int textColorAlertDialogListItem = 16843526;
        public static final int textColorHighlight = 16842905;
        public static final int textColorHighlightInverse = 16843599;
        public static final int textColorHint = 16842906;
        public static final int textColorHintInverse = 16842815;
        public static final int textColorLink = 16842907;
        public static final int textColorLinkInverse = 16843600;
        public static final int textColorPrimary = 16842806;
        public static final int textColorPrimaryDisableOnly = 16842807;
        public static final int textColorPrimaryInverse = 16842809;
        public static final int textColorPrimaryInverseDisableOnly = 16843403;
        public static final int textColorPrimaryInverseNoDisable = 16842813;
        public static final int textColorPrimaryNoDisable = 16842811;
        public static final int textColorSecondary = 16842808;
        public static final int textColorSecondaryInverse = 16842810;
        public static final int textColorSecondaryInverseNoDisable = 16842814;
        public static final int textColorSecondaryNoDisable = 16842812;
        public static final int textColorTertiary = 16843282;
        public static final int textColorTertiaryInverse = 16843283;
        public static final int textCursorDrawable = 16843618;
        public static final int textDirection = 16843696;
        public static final int textEditNoPasteWindowLayout = 16843541;
        public static final int textEditPasteWindowLayout = 16843540;
        public static final int textEditSideNoPasteWindowLayout = 16843615;
        public static final int textEditSidePasteWindowLayout = 16843614;
        public static final int textEditSuggestionItemLayout = 16843636;
        public static final int textFilterEnabled = 16843007;
        public static final int textFontWeight = 16844165;
        public static final int textIsSelectable = 16843542;
        public static final int textLocale = 16844178;
        public static final int textOff = 16843045;
        public static final int textOn = 16843044;
        public static final int textScaleX = 16843089;
        public static final int textSelectHandle = 16843463;
        public static final int textSelectHandleLeft = 16843461;
        public static final int textSelectHandleRight = 16843462;
        public static final int textSelectHandleWindowStyle = 16843464;
        public static final int textSize = 16842901;
        public static final int textStyle = 16842903;
        public static final int textSuggestionsWindowStyle = 16843635;
        public static final int textViewStyle = 16842884;
        public static final int theme = 16842752;
        public static final int thickness = 16843360;
        public static final int thicknessRatio = 16843164;
        public static final int thumb = 16843074;
        public static final int thumbOffset = 16843075;
        public static final int thumbPosition = 16844005;
        public static final int thumbTextPadding = 16843634;
        public static final int thumbTint = 16843889;
        public static final int thumbTintMode = 16843890;
        public static final int thumbnail = 16843429;
        public static final int tickMark = 16844042;
        public static final int tickMarkTint = 16844043;
        public static final int tickMarkTintMode = 16844044;
        public static final int tileMode = 16843265;
        public static final int tileModeX = 16843895;
        public static final int tileModeY = 16843896;
        public static final int timePickerDialogTheme = 16843934;
        public static final int timePickerMode = 16843956;
        public static final int timePickerStyle = 16843933;
        public static final int timeZone = 16843724;
        public static final int tint = 16843041;
        public static final int tintMode = 16843771;
        public static final int title = 16843233;
        public static final int titleCondensed = 16843234;
        public static final int titleMargin = 16844024;
        public static final int titleMarginBottom = 16844028;
        public static final int titleMarginEnd = 16844026;
        public static final int titleMarginStart = 16844025;
        public static final int titleMarginTop = 16844027;
        public static final int titleTextAppearance = 16843822;
        public static final int titleTextColor = 16844003;
        public static final int titleTextStyle = 16843512;
        public static final int toAlpha = 16843211;
        public static final int toDegrees = 16843188;
        public static final int toId = 16843849;
        public static final int toScene = 16843742;
        public static final int toXDelta = 16843207;
        public static final int toXScale = 16843203;
        public static final int toYDelta = 16843209;
        public static final int toYScale = 16843205;
        public static final int toolbarStyle = 16843946;
        public static final int tooltipText = 16844084;
        public static final int top = 16843182;
        public static final int topBright = 16842955;
        public static final int topDark = 16842951;
        public static final int topLeftRadius = 16843177;
        public static final int topOffset = 16843352;
        public static final int topRightRadius = 16843178;
        public static final int touchscreenBlocksFocus = 16843919;
        public static final int track = 16843631;
        public static final int trackTint = 16843993;
        public static final int trackTintMode = 16843994;
        public static final int transcriptMode = 16843008;
        public static final int transformPivotX = 16843552;
        public static final int transformPivotY = 16843553;
        public static final int transition = 16843743;
        public static final int transitionGroup = 16843777;
        public static final int transitionName = 16843776;
        public static final int transitionOrdering = 16843744;
        public static final int transitionVisibilityMode = 16843900;
        public static final int translateX = 16843866;
        public static final int translateY = 16843867;
        public static final int translationX = 16843554;
        public static final int translationY = 16843555;
        public static final int translationZ = 16843770;
        public static final int trimPathEnd = 16843785;
        public static final int trimPathOffset = 16843786;
        public static final int trimPathStart = 16843784;
        public static final int ttcIndex = 16844143;
        public static final int tunerCount = 16844061;
        public static final int turnScreenOn = 16844138;
        public static final int type = 16843169;
        public static final int typeface = 16842902;
        public static final int uiOptions = 16843672;
        public static final int uncertainGestureColor = 16843382;
        /** @deprecated */
        @Deprecated
        public static final int unfocusedMonthDateColor = 16843588;
        public static final int unselectedAlpha = 16843278;
        public static final int updatePeriodMillis = 16843344;
        public static final int use32bitAbi = 16844053;
        public static final int useAppZygote = 16844183;
        public static final int useDefaultMargins = 16843641;
        public static final int useEmbeddedDex = 16844190;
        public static final int useIntrinsicSizeAsMinimum = 16843536;
        public static final int useLevel = 16843167;
        public static final int userVisible = 16843409;
        public static final int usesCleartextTraffic = 16844012;
        public static final int value = 16842788;
        public static final int valueFrom = 16843486;
        public static final int valueTo = 16843487;
        public static final int valueType = 16843488;
        public static final int variablePadding = 16843157;
        public static final int vendor = 16843751;
        public static final int version = 16844057;
        public static final int versionCode = 16843291;
        public static final int versionCodeMajor = 16844150;
        public static final int versionMajor = 16844151;
        public static final int versionName = 16843292;
        /** @deprecated */
        @Deprecated
        public static final int verticalCorrection = 16843322;
        public static final int verticalDivider = 16843054;
        /** @deprecated */
        @Deprecated
        public static final int verticalGap = 16843328;
        public static final int verticalScrollbarPosition = 16843572;
        public static final int verticalSpacing = 16843029;
        public static final int viewportHeight = 16843779;
        public static final int viewportWidth = 16843778;
        public static final int visibility = 16842972;
        public static final int visible = 16843156;
        public static final int visibleToInstantApps = 16844081;
        public static final int vmSafeMode = 16843448;
        public static final int voiceIcon = 16843908;
        public static final int voiceLanguage = 16843349;
        public static final int voiceLanguageModel = 16843347;
        public static final int voiceMaxResults = 16843350;
        public static final int voicePromptText = 16843348;
        public static final int voiceSearchMode = 16843346;
        public static final int wallpaperCloseEnterAnimation = 16843413;
        public static final int wallpaperCloseExitAnimation = 16843414;
        public static final int wallpaperIntraCloseEnterAnimation = 16843417;
        public static final int wallpaperIntraCloseExitAnimation = 16843418;
        public static final int wallpaperIntraOpenEnterAnimation = 16843415;
        public static final int wallpaperIntraOpenExitAnimation = 16843416;
        public static final int wallpaperOpenEnterAnimation = 16843411;
        public static final int wallpaperOpenExitAnimation = 16843412;
        public static final int webTextViewStyle = 16843449;
        public static final int webViewStyle = 16842885;
        public static final int weekDayTextAppearance = 16843592;
        /** @deprecated */
        @Deprecated
        public static final int weekNumberColor = 16843589;
        /** @deprecated */
        @Deprecated
        public static final int weekSeparatorLineColor = 16843590;
        public static final int weightSum = 16843048;
        public static final int widgetCategory = 16843716;
        public static final int widgetFeatures = 16844153;
        public static final int widgetLayout = 16843243;
        public static final int width = 16843097;
        public static final int windowActionBar = 16843469;
        public static final int windowActionBarOverlay = 16843492;
        public static final int windowActionModeOverlay = 16843485;
        public static final int windowActivityTransitions = 16843981;
        public static final int windowAllowEnterTransitionOverlap = 16843836;
        public static final int windowAllowReturnTransitionOverlap = 16843835;
        public static final int windowAnimationStyle = 16842926;
        public static final int windowBackground = 16842836;
        public static final int windowBackgroundFallback = 16844035;
        public static final int windowClipToOutline = 16843947;
        public static final int windowCloseOnTouchOutside = 16843611;
        public static final int windowContentOverlay = 16842841;
        public static final int windowContentTransitionManager = 16843769;
        public static final int windowContentTransitions = 16843768;
        public static final int windowDisablePreview = 16843298;
        public static final int windowDrawsSystemBarBackgrounds = 16843856;
        public static final int windowElevation = 16843920;
        public static final int windowEnableSplitTouch = 16843543;
        public static final int windowEnterAnimation = 16842932;
        public static final int windowEnterTransition = 16843831;
        public static final int windowExitAnimation = 16842933;
        public static final int windowExitTransition = 16843832;
        public static final int windowFrame = 16842837;
        public static final int windowFullscreen = 16843277;
        public static final int windowHideAnimation = 16842935;
        public static final int windowIsFloating = 16842839;
        public static final int windowIsTranslucent = 16842840;
        public static final int windowLayoutInDisplayCutoutMode = 16844166;
        public static final int windowLightNavigationBar = 16844140;
        public static final int windowLightStatusBar = 16844000;
        public static final int windowMinWidthMajor = 16843606;
        public static final int windowMinWidthMinor = 16843607;
        public static final int windowNoDisplay = 16843294;
        public static final int windowNoTitle = 16842838;
        public static final int windowOverscan = 16843727;
        public static final int windowReenterTransition = 16843951;
        public static final int windowReturnTransition = 16843950;
        public static final int windowSharedElementEnterTransition = 16843833;
        public static final int windowSharedElementExitTransition = 16843834;
        public static final int windowSharedElementReenterTransition = 16843953;
        public static final int windowSharedElementReturnTransition = 16843952;
        public static final int windowSharedElementsUseOverlay = 16843963;
        public static final int windowShowAnimation = 16842934;
        public static final int windowShowWallpaper = 16843410;
        public static final int windowSoftInputMode = 16843307;
        public static final int windowSplashscreenContent = 16844132;
        public static final int windowSwipeToDismiss = 16843763;
        public static final int windowTitleBackgroundStyle = 16842844;
        public static final int windowTitleSize = 16842842;
        public static final int windowTitleStyle = 16842843;
        public static final int windowTransitionBackgroundFadeDuration = 16843873;
        public static final int windowTranslucentNavigation = 16843760;
        public static final int windowTranslucentStatus = 16843759;
        public static final int writePermission = 16842760;
        public static final int x = 16842924;
        public static final int xlargeScreens = 16843455;
        public static final int y = 16842925;
        /** @deprecated */
        @Deprecated
        public static final int yearListItemTextAppearance = 16843929;
        /** @deprecated */
        @Deprecated
        public static final int yearListSelectorColor = 16843930;
        public static final int yesNoPreferenceStyle = 16842896;
        public static final int zAdjustment = 16843201;
        public static final int zygotePreloadName = 16844189;

        public attr() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class array {
        public static final int emailAddressTypes = 17235968;
        public static final int imProtocols = 17235969;
        public static final int organizationTypes = 17235970;
        public static final int phoneTypes = 17235971;
        public static final int postalAddressTypes = 17235972;

        public array() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class animator {
        public static final int fade_in = 17498112;
        public static final int fade_out = 17498113;

        public animator() {
            throw new RuntimeException("Stub!");
        }
    }

    public static final class anim {
        public static final int accelerate_decelerate_interpolator = 17432580;
        public static final int accelerate_interpolator = 17432581;
        public static final int anticipate_interpolator = 17432583;
        public static final int anticipate_overshoot_interpolator = 17432585;
        public static final int bounce_interpolator = 17432586;
        public static final int cycle_interpolator = 17432588;
        public static final int decelerate_interpolator = 17432582;
        public static final int fade_in = 17432576;
        public static final int fade_out = 17432577;
        public static final int linear_interpolator = 17432587;
        public static final int overshoot_interpolator = 17432584;
        public static final int slide_in_left = 17432578;
        public static final int slide_out_right = 17432579;

        public anim() {
            throw new RuntimeException("Stub!");
        }
    }
}
