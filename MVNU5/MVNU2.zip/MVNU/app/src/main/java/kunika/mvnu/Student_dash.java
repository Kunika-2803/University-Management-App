package kunika.mvnu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Student_dash extends AppCompatActivity {
TextView name;
CardView attendance,study,fees,library,gradesheet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_dash);
        attendance=findViewById(R.id.attendance);
        attendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),Attendance.class);
                startActivity(i);
            }
        });
        study=findViewById(R.id.Study);
        study.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),Study_Material.class);
                startActivity(i);
            }
        });
        fees=findViewById(R.id.feePayment);
        fees.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),Fee_Payment.class);
                startActivity(i);
            }
        });
        library=findViewById(R.id.library);
        library.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),Library.class);
                startActivity(i);
            }
        });
        gradesheet=findViewById(R.id.gradesheet);
        gradesheet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),Grade_Sheet.class);
                startActivity(i);
            }
        });
        name= (TextView) findViewById(R.id.name);
        Intent intent=getIntent();
        String var=intent.getStringExtra(Login.vari);
        name.setText(var);
    }
    public void Edit(View view)
    {
        Intent i=new Intent(getApplicationContext(),Edit_Profile.class);
        startActivity(i);
    }
    public void Event(View view)
    {
        Intent i=new Intent(getApplicationContext(),Event.class);
        startActivity(i);
    }
}
