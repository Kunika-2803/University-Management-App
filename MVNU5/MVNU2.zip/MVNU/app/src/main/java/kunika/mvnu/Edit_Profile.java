package kunika.mvnu;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.hitomi.cmlibrary.CircleMenu;
import com.hitomi.cmlibrary.OnMenuSelectedListener;
import com.hitomi.cmlibrary.OnMenuStatusChangeListener;

public class Edit_Profile extends AppCompatActivity {
  //  CircleMenu circle;
   // String[] name={"Event","Attendance","Study Material","Library","Fees","Result"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit__profile);
       // circle= (CircleMenu) findViewById(R.id.circle);
      //  circle.setMainMenu(Color.parseColor("#CDCDCD"),R.drawable.ic_action_name,R.drawable.remove)
          //      .addSubMenu(Color.parseColor("#258CFF"),R.drawable.event)
          //      .addSubMenu(Color.parseColor("#6d4c41"),R.drawable.attendance)
          //      .addSubMenu(Color.parseColor("#FF0000"),R.drawable.notes)
           //     .addSubMenu(Color.parseColor("#00a9f4"),R.drawable.library)
          //      .addSubMenu(Color.parseColor("#258CFF"),R.drawable.fees)
          //      .addSubMenu(Color.parseColor("#258CFF"),R.drawable.result)
          //      .setOnMenuSelectedListener(new OnMenuSelectedListener() {
            //        @Override
              //      public void onMenuSelected(int index) {
                //        Toast.makeText(Edit_Profile.this, "You Selected "+name[index], Toast.LENGTH_SHORT).show();
                  //  }
                //});
        //circle.setOnMenuStatusChangeListener(new OnMenuStatusChangeListener() {
          //  @Override
            //public void onMenuOpened() {

            //}

            //@Override
            //public void onMenuClosed() {

            //}
        //});
    }
}
