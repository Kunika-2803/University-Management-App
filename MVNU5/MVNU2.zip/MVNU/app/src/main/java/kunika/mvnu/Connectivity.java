package kunika.mvnu;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class Connectivity {
    private static final String url = "jdbc:mysql://192.168.43.159:3306/mvn_admin";
    private static final String user = "kk212";
    private static final String pass = "!Kunika_123";
    private static Statement st;
    private static ResultSet rs = null;
    public static void Connect()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            System.out.println("Databaseection success");

            String result = "Database Connection Successful\n";
            st = con.createStatement();
        }
        catch(Exception e)
        {

        }
    }
    public static ResultSet Login(String user,String pass)
    {

        String res = "";
        try {
            Connect();
            rs = st.executeQuery("select * from student_register where Roll_No='"+user+"' And Password='"+pass+"'");
            ResultSetMetaData rsmd = rs.getMetaData();
        } catch (Exception e) {
            e.printStackTrace();
            res = e.toString();
        }
        return rs;
    }
    public static String Register(String name,String roll,String email,String gender,String mobile,String pass,String Course,String Sem)
    {
        String res="";
        try
        {
            Connect();
            st.executeUpdate("Insert into student_register(Name,Roll_No,Email,Mobile_No,Password,dept_id,Sem,Gender) values('"+name+"','"+roll+"','"+email+"','"+mobile+"','"+pass+"','"+Course+"','"+Sem+"','"+gender+"')");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            res=e.toString();
        }
        return res;
    }
    public static ResultSet dept_id(String dept_name)
    {
        String res="";
        try
        {
            Connect();
            rs=st.executeQuery("select dept_id from department where dept_name='"+dept_name+"'");

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return rs;
    }
    public static ResultSet dept_name()
    {
        try
        {
            Connect();
            rs=st.executeQuery("select dept_name from department");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return rs;
    }
}
