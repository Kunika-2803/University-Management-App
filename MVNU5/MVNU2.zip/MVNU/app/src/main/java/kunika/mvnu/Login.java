package kunika.mvnu;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.ResultSet;

public class Login extends AppCompatActivity {
    EditText user,password;
    TextView error;
    public Boolean flag=false,isNameValid,isPassValid;
    public static String vari="kunika.mvnu.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        user= (EditText) findViewById(R.id.user);
        password= (EditText) findViewById(R.id.password);
        error= (TextView) findViewById(R.id.error);
        Intent intent=getIntent();
        String var=intent.getStringExtra(MainActivity.var);
    }
    public void Login(View view)
    {
        SetValidation();
        if(isNameValid&&isPassValid) {
            error.setText("");
            new LogIn().execute();
        }
    }
    private class LogIn extends AsyncTask<String,Void,String>
    {
        String name="";
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(Login.this, "Please wait...", Toast.LENGTH_SHORT)
                    .show();

        }
        @Override
        protected String doInBackground(String... strings) {

            try {
                ResultSet rs = Connectivity.Login(user.getText().toString(),password.getText().toString());
                if(rs.next())
                {
                    flag=true;
                    name=rs.getString("Name");
                }
                else
                {
                    name="Invalid Username or password";
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
                name=e.toString();

            }
            return name;
        }
        @Override
        protected void onPostExecute(String result) {
            if(flag)
            {
                Intent inte=new Intent(getApplicationContext(),Student_dash.class);
                inte.putExtra(vari,result);
                startActivity(inte);
            }
            else {
                error.setText(result);
            }
        }
    }
    public void SetValidation()
    {
        if (user.getText().toString().isEmpty()) {
            user.setError(getResources().getString(R.string.user_error));
            isNameValid = false;
        } else  {
            isNameValid = true;
        }
        if (password.getText().toString().isEmpty()) {
            password.setError(getResources().getString(R.string.password_error));
            isPassValid = false;
        } else  {
            isPassValid = true;
        }
    }
    public void Register(View view)
    {
        Intent i = new Intent(getApplicationContext(),Register.class);
        startActivity(i);
    }
}
